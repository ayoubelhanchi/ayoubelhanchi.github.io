import torch
from .layers import Linear, Conv2d


class Model(torch.nn.Module):

    def __init__(self, requires_grads=False, requires_norms=False,
                 requires_weighted_grad=False):
        super().__init__()
        self.requires_grads = requires_grads
        self.requires_norms = requires_norms
        self.requires_weighted_grad = requires_weighted_grad
        if self.requires_grads:
            self.requires_grads_()
        if self.requires_norms:
            self.requires_norms_()
        if self.requires_weighted_grad:
            self.requires_weighted_grad_()

    def requires_grads_(self, requires_grads=True):
        def temp(m):
            if type(m) in [Linear, Conv2d]:
                m.requires_grads = requires_grads
        self.apply(temp)
        self.requires_grads = requires_grads

    def requires_norms_(self, requires_norms=True):
        def temp(m):
            if type(m) in [Linear, Conv2d]:
                m.requires_norms = requires_norms
        self.apply(temp)
        self.requires_norms = requires_norms

    def requires_weighted_grad_(self, requires_weighted_grad=True):
        def temp(m):
            if type(m) in [Linear, Conv2d]:
                m.requires_weighted_grad = requires_weighted_grad
        self.apply(temp)
        self.requires_weighted_grad = requires_weighted_grad

    def grads_norms(self):
        norms = torch.zeros_like(list(self.parameters())[0].norms)
        for p in self.parameters():
            norms += p.norms.pow(2)
        return norms.sqrt()

    def grad_variance(self):
        # (trace) of variance estimator
        pass
