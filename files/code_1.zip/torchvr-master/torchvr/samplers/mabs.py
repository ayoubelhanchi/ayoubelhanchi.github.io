from math import sqrt, pow, log
import torch

from .importance_sampler import ImportanceSampler
from _cpp import WeightedUniformSampler


class Mabs(ImportanceSampler):
    """Implements the multi-armed bandit sampling algorithm.
    Complexity O(mlogN) where m is the batch size and N is the size of the data.
    Does not support sampling without replacement.

    References:
        - Farnood Salehi, L. Elisa Celis, Patrick Thiran
            Stochastic Optimization with Bandit Sampling,
            arXiv:1708.02544v2 [cs.LG], 2017 (available at
            https://arxiv.org/abs/1708.02544v2)
    """

    def __init__(self, data, params, batch_size, replace=True, yield_weights=False,
                 eta=0.4, G=None, T=None):
        if replace is False:
            raise ValueError(
                "Mabs does not support sampling without replacement.")
        super().__init__(data, params, batch_size, replace, yield_weights)

        # defines the step size
        self._eta = eta
        self._delta = self._batch_size * sqrt(pow(self._eta, 4) * log(self._N) /
                                              (T * pow(self._N, 5) * pow(G, 4)))

        # initializes the sampler
        self._bernoullis = torch.empty(batch_size, dtype=torch.bool)
        self._uniforms = torch.empty(batch_size, dtype=torch.float64)
        self._sampler = WeightedUniformSampler(torch.ones(self._N))

    def get_probs(self):
        return torch.from_numpy(
            self._sampler.get_probs(1-self._eta)
        ).to(torch.get_default_dtype())

    def reset(self):
        self._sampler = WeightedUniformSampler(torch.ones(self._N))

    def _sample(self):
        self._bernoullis.bernoulli_(1 - self._eta)
        self._uniforms.uniform_()
        self._sampler.sample(self._bernoullis.numpy(), self._uniforms.numpy(),
                             self._indices.numpy(), self._probs.numpy(),
                             1-self._eta)

    def _update(self):
        torch.pow(self._probs, 3, out=self._tmp)
        torch.div(self._norms.pow_(2), self._tmp, out=self._tmp)
        self._tmp *= self._delta
        self._tmp.exp_()
        self._sampler.update(self._indices.numpy(), self._tmp.numpy(),
                             mode=2)
