from math import pow
import torch

from .importance_sampler import ImportanceSampler
from _cpp import WeightedUniformSampler


class Vrb(ImportanceSampler):
    """Implements the Variance Reducer Bandit algorithm.
    Complexity O(mlogN) where m is the batch size and N is the size of the data.
    Does not support sampling without replacement.

    G is a bound on the gradient norms.
    T is the total number of iterations.

    References:
        - Zalan Brosos, Andreas Krause, Kfir Y. Levy, 
            Online Variance Reduction for Stochastic Optimization,
            arXiv:1802.04715 [stat.ML], 2018 (available at
            https://arxiv.org/pdf/1802.04715.pdf)
    """

    def __init__(self, data, params, batch_size, replace=True, yield_weights=False,
                 G=None, T=None):
        if replace is False:
            raise ValueError(
                "Vrb does not support sampling without replacement.")
        super().__init__(data, params, batch_size, replace, yield_weights)

        # constructs the initial weights
        self._G = G
        self._theta = pow(self._N/T, 1/3)
        init_weights = (pow(self._G, 2) * (self._N/self._theta)) * \
            torch.ones(self._N, dtype=torch.float64)

        # initializes the sampler
        self._bernoullis = torch.empty(batch_size, dtype=torch.bool)
        self._uniforms = torch.empty(batch_size, dtype=torch.float64)
        self._sampler = WeightedUniformSampler(init_weights)

    def get_probs(self):
        return torch.from_numpy(
            self._sampler.get_probs(1-self._theta)
        ).to(torch.get_default_dtype())

    def reset(self):
        init_weights = (pow(self._G, 2) * (self._N/self._theta)) * \
            torch.ones(self._N, dtype=torch.float64)
        self._sampler = WeightedUniformSampler(init_weights)

    def _sample(self):
        self._bernoullis.bernoulli_(1-self._theta)
        self._uniforms.uniform_()
        self._sampler.sample(self._bernoullis.numpy(), self._uniforms.numpy(),
                             self._indices.numpy(), self._probs.numpy(),
                             1-self._theta)

    def _update(self):
        torch.mul(self._norms.pow_(2), self._weights, out=self._tmp)
        self._sampler.update(self._indices.numpy(), self._tmp.numpy(),
                             mode=3)
