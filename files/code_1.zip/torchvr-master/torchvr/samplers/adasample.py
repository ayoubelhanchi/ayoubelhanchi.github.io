from math import pow
import torch

from .importance_sampler import ImportanceSampler
from _cpp import OptimalSampler


class AdaSample(ImportanceSampler):
    """Implements the AdaSample algorithm.
    Complexity O(mlogN) where m is the batch size and N is the size of the data.

    Arguments:
        - init_norms (tensor): the inital gradient norms.
            If None, they are set to 0. Default: None.
        - delta (float): constant (>0) determining the decay schedule.
            see original paper. Default: 1.0.
        - p_min (float): global lower bound on the probability of sampling
            an index. must be in [0, 1/N] where N is the size of the data.
            see original paper. Default: 0.0.
        - C (float): constant determining the decay schedule.
            see original paper. Default: 1/(1/N - p_min)
            where N is the size of the data and p_min as above.
        - delete_while_sampling (bool): When sampling without
            replacement, whether to delete the nodes containing the
            sampled indices from the underlying red-black tree or not.
            Set to True for an additional speed-up when the sampled
            indices are updated before sampling occurs again.
            Default:False.
    """

    def __init__(self, data, params, batch_size, replace=False, yield_weights=False,
                 init_norms=None, C=None, delta=1.0, p_min=0.0,
                 delete_while_sampling=True):
        super().__init__(data, params, batch_size, replace, yield_weights)

        # defines the eps schedule
        C = 1/(1/self._N - p_min) if (C is None) else C
        self._iter_num = 0
        m = self._batch_size
        self._eps = \
            lambda t: 1/(pow(C, 1-(delta/3)) * pow(C + m * t, delta/3)) + p_min

        # initializes the sampler
        self._uniforms = torch.empty(batch_size, dtype=torch.float64)
        if init_norms is None:
            self._sampler = OptimalSampler(self._N)
        else:
            self._sampler = \
                OptimalSampler(init_norms.cpu().to(torch.float64).numpy())

        self.delete_while_sampling = delete_while_sampling

    def get_probs(self):
        return torch.from_numpy(
            self._sampler.get_probs(self._eps(self._iter_num))
        ).to(torch.get_default_dtype())

    def reset(self):
        self._sampler = OptimalSampler(self._N)
        self._iter_num = 0

    def _sample(self):
        self._uniforms.uniform_()
        self._sampler.sample(self._uniforms.numpy(),
                             self._indices.numpy(), self._probs.numpy(),
                             self._replace, self._eps(self._iter_num),
                             self.delete_while_sampling)

    def _update(self):
        self._sampler.update(self._indices.numpy(), self._norms.numpy())
        self._iter_num += 1
