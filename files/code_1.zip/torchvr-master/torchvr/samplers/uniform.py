import torch

from .importance_sampler import ImportanceSampler
from _cpp import UniformSampler


class Uniform(ImportanceSampler):
    """Samples indices uniformly.
    Complexity O(m) where m is the batch size.

    Arguments:
        Same as parent class 'ImportanceSampler'.
    """

    def __init__(self, data, params, batch_size, replace=False, yield_weights=False):
        super().__init__(data, params, batch_size, replace, yield_weights)
        self._probs = torch.ones(batch_size, dtype=torch.float64).div_(self._N)
        if self._replace is False:
            self._uniforms = torch.empty(batch_size, dtype=torch.float64)
            self._sampler = UniformSampler(self._N)

    def get_probs(self):
        return torch.ones(self._N)/self._N

    def reset(self):
        if self._replace is False:
            self._sampler = UniformSampler(self._N)

    def _sample(self):
        if self._replace:
            torch.randint(0, self._N,
                          size=(self._batch_size,),
                          out=self._indices)
        else:
            self._uniforms.uniform_()
            self._sampler.sample(self._uniforms.numpy(), self._indices.numpy())

    def _update(self):
        pass
