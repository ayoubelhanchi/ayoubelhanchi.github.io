import torch


class ImportanceSampler(torch.utils.data.Sampler):
    """Base class for all Importance Samplers.

    Every Importance Sampler subclass needs to implements the methods
    '_sample' and '_update'. See the description of these methods below.

    Arguments:
        data (Dataset): dataset to sample from.
        params (iterable): the parameters of the model.
        batch_size (int): size of mini-batch.
        replace (bool): whether to sample with or without replacement.
            Default: False.
        yield_weights (bool): if True, yields a tuple (indices, weights_grad)
            when iterated over. Otherwise, only yields the
            sampled indices. Default: False.
    """

    def __init__(self, data, params, batch_size, replace=False, yield_weights=False):

        self._N = len(data)
        self._batch_size = batch_size
        self._replace = replace
        self._yield_weights = yield_weights

        self._params = list(params)
        self._norms = torch.empty(batch_size, dtype=torch.float64)

        self._indices = torch.empty(batch_size, dtype=torch.int64)
        self._probs = torch.empty(batch_size, dtype=torch.float64)
        self._weights = torch.empty(batch_size, dtype=torch.float64)

        # temp tensor used for intermediate calculations the weights
        self._tmp = torch.empty(batch_size, dtype=torch.float64)

        # second term of the gradient weights when sampling without replacement
        self._index_weights = \
            torch.arange(1, self._batch_size + 1,
                         dtype=torch.float64).div_(self._batch_size)
        self._index_weights.neg_().add_(1.0)

    def __iter__(self):
        for _ in range(self._N // self._batch_size):
            self._sample()
            self._set_weights()
            if self._yield_weights:
                yield self._indices, self._weights.to(torch.get_default_dtype())
            else:
                yield self._indices

    def __len__(self):
        return self.N // self.batch_size

    def step(self):
        """Updates the distribution of the sampler.
        Assumes the parameters have an attribute 'norms'
        storing the squared norms of the gradients."""
        self._set_norms()
        self._update()

    def get_probs(self):
        """Computes and returns the current distribution of the sampler."""
        raise NotImplementedError

    def reset(self):
        """Resets the sampler to its initial state."""
        raise NotImplementedError

    def _sample(self):
        """Implements the sampling procedure.

        Side-Effect: Fills the tensor attributes '_indices' and '_probs'
            with the sampled indices and their probabilities respectively.
        """
        raise NotImplementedError

    def _update(self):
        """Implements the update to the distribution of the sampler
        using the attribute '_norms' containing the gradient
        norms of the current mini-batch.
        """
        raise NotImplementedError

    @property
    def weights(self):
        return self._weights.to(torch.get_default_dtype())

    def _set_weights(self):
        if self._replace:
            torch.mul(self._probs, self._batch_size, out=self._tmp)
            torch.reciprocal(self._tmp, out=self._weights)
        else:
            torch.cumsum(self._probs, dim=0, out=self._tmp)
            self._tmp -= self._probs
            self._tmp.neg_().add_(1.0)
            self._tmp /= self._probs
            self._tmp /= self._batch_size
            torch.add(self._tmp, self._index_weights,
                      alpha=1, out=self._weights)

    def _set_norms(self):
        self._norms.zero_()
        for p in self._params:
            self._norms += p.norms.pow(2)
        self._norms.sqrt_()
