#ifndef GLOBALS_H
#define GLOBALS_H

#include <cstdint>
#include <cstddef>

typedef std::uint32_t uint32;
typedef std::int32_t int32;
typedef float float32;

typedef std::uint64_t uint64;
typedef std::int64_t int64;
typedef double float64;

typedef std::size_t size_t;

#endif