#ifndef OPTIMAL_SAMPLER_H
#define OPTIMAL_SAMPLER_H

#include <vector>

#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>

#include "globals.hpp"
#include "node.hpp"
#include "tree.hpp"

namespace py = pybind11;

class OptimalSampler
{
public:
    // attributes
    size_t N;
    Tree weights;

    // attributes of optimal node
    size_t r_star = 0;
    float64 s_star = 0.0;
    float64 c_star = 1.0;
    float64 key_star = 0.0;

    // constructor
    OptimalSampler(size_t N);
    OptimalSampler(py::array_t<float64> init_weights);

    // core
    void update(py::array_t<int64> indices,
                py::array_t<float64> new_weights);

    void sample(py::array_t<float64> uniforms,
                py::array_t<int64> sampled_indices,
                py::array_t<float64> sampled_probs,
                bool replace,
                float64 eps,
                bool del);

    void solve(float64 eps);
    py::array_t<float64> get_probs(float64 eps);
};
#endif