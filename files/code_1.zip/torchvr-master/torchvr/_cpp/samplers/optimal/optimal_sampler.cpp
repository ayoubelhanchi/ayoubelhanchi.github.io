#include <vector>

#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>

#include "globals.hpp"
#include "node.hpp"
#include "tree.hpp"
#include "optimal_sampler.hpp"

namespace py = pybind11;

// constructors
OptimalSampler::OptimalSampler(size_t N)
    : N{N},
      weights(N)
{
    // constructs the tree
    for (size_t i = 0; i < N; ++i)
        weights.set_key_at_index(i, 0.0);
}

OptimalSampler::OptimalSampler(py::array_t<float64> init_weights)
    : N{init_weights.size()},
      weights(N)
{
    // reads the buffer info of the array
    py::buffer_info buf_init_weights = init_weights.request();

    // obtains pointer to the array
    float64 *ptr_init_weights = (float64 *)buf_init_weights.ptr;

    // initializes the weights
    for (size_t i = 0; i < buf_init_weights.size; ++i)
        weights.set_key_at_index(i, ptr_init_weights[i]);
}

// core
void OptimalSampler::update(py::array_t<int64> indices,
                            py::array_t<float64> new_weights)
{

    // reads the buffer info of the arrays
    py::buffer_info buf_indices = indices.request();
    py::buffer_info buf_new_weights = new_weights.request();

    // obtains pointers to the arrays
    int64 *ptr_indices = (int64 *)buf_indices.ptr;
    float64 *ptr_new_weights = (float64 *)buf_new_weights.ptr;

    // sets the new weights to the given indices
    for (size_t i = 0; i < buf_indices.size; ++i)
        weights.set_key_at_index(ptr_indices[i], ptr_new_weights[i]);
}

void OptimalSampler::sample(py::array_t<float64> uniforms,
                            py::array_t<int64> sampled_indices,
                            py::array_t<float64> sampled_probs,
                            bool replace,
                            float64 eps,
                            bool del)
{
    // solves the optimization problem
    solve(eps);

    // if all keys are 0, sample uniformly
    if (r_star == 0)
        eps = 1 / (float64)N;

    // reads the buffer info of the arrays
    py::buffer_info buf_uniforms = uniforms.request();
    py::buffer_info buf_sampled_indices = sampled_indices.request();
    py::buffer_info buf_sampled_probs = sampled_probs.request();

    // obtains pointers to the arrays
    float64 *ptr_uniforms = (float64 *)buf_uniforms.ptr;
    int64 *ptr_sampled_indices = (int64 *)buf_sampled_indices.ptr;
    float64 *ptr_sampled_probs = (float64 *)buf_sampled_probs.ptr;

    // initializes local variables needed for algorithm
    float64 u;
    Node *z;
    uint64 n_eps = N - r_star;          // total number of nodes with prob == eps
    uint64 r_eps;                       // left rank of the sampled node when it has prob == eps
    float64 s_gt_eps = s_star / c_star; // (normalized) sum of the weights of the nodes with prob > eps
    float64 nc = 1.0;                   // normalization constant when sampling without replacement
    size_t sampled_index;
    float64 sampled_prob;

    // samples from the optimal distribution
    for (size_t i = 0; i < buf_uniforms.size; ++i)
    {
        // gets the uniform [0,1) random variable
        u = ptr_uniforms[i];

        // finds the sampled index
        if (u < 1 - (eps / nc) * n_eps)
        {
            // uniform falls in the interval dedicated to indices with prob > eps
            sampled_index = weights.select_right_cumsum(u * s_gt_eps * nc);
            sampled_prob = weights.get_key_at_index(sampled_index) / s_gt_eps;
        }
        else
        {
            // uniform falls in the interval dedicated to indices with probs == eps
            u -= 1 - (eps / nc) * n_eps;
            r_eps = (size_t)(u * nc / eps) + 1;
            sampled_index = weights.select_left(r_eps);
            sampled_prob = eps;

            if (!replace)
                // decreases the number of elements with eps prob
                n_eps -= 1;
        }
        // assigns the sampled index and probability
        ptr_sampled_indices[i] = sampled_index;
        ptr_sampled_probs[i] = sampled_prob;

        // hides the sampled indices if sampling without replacement
        if (!replace)
        {
            // updates normalization constant
            nc -= sampled_prob;
            // deletes or hides the sampled node
            z = &weights.nodes[sampled_index];
            if (del)
                weights._delete(z);
            else
                z->hide(weights.NIL);
        }
    }

    // unhides the sampled nodes after sampling is finished
    if (!replace && !del)
        for (size_t i = 0; i < buf_uniforms.size; ++i)
            weights.nodes[ptr_sampled_indices[i]].unhide(weights.NIL);
}

// O(logN) solve, stores the results in the attributes
void OptimalSampler::solve(float64 eps)
{
    // all keys are 0 or
    // edge case eps == 1/N causes numerical instability,
    // we handle it here
    if (weights.get_sum_of_keys() == 0 || eps == 1 / (float64)N)
    {
        r_star = 0;
        s_star = 0.0;
        c_star = 1;
        key_star = 0.0;
        return;
    }

    // local variables
    Node *x = weights.root;
    size_t r = x->right->size + 1;      // the current rank of x
    float64 s = x->right->sum + x->key; // the current right cumsum of x
    float64 c = 1 - (N - r) * eps;      // normalization constant

    // O(logN)
    while (x != weights.NIL)
    {
        if (x->key >= eps * (s / c))
        {
            r_star = r;
            s_star = s;
            c_star = c;
            key_star = x->key;
            x = x->left;
            if (x != weights.NIL)
            {
                r += x->right->size + 1;
                s += x->right->sum + x->key;
                c = 1 - (N - r) * eps;
            }
        }
        else
        {
            x = x->right;
            if (x != weights.NIL)
            {
                r -= (x->left->size + 1);
                s -= (x->left->sum + x->p->key); // remove the parent's key since we are not counting the parent anymore
                c = 1 - (N - r) * eps;
            }
        }
    }
}
py::array_t<float64> OptimalSampler::get_probs(float64 eps)
{
    // solves the optimization problem
    solve(eps);

    // creates an array holding the results
    py::array_t<float64> probs = py::array_t<float64>(N);

    // gets a pointer to the data
    py::buffer_info buf_probs = probs.request();
    float64 *ptr_probs = (float64 *)buf_probs.ptr;

    // computes and returns the probabilities
    if (r_star == 0)
    {
        float64 inv_N = 1 / (float64)N;
        for (size_t i = 0; i < buf_probs.size; i++)
            ptr_probs[i] = inv_N;
    }
    else
    {
        float64 s_gt_eps = s_star / c_star;
        float64 key;
        for (size_t i = 0; i < buf_probs.size; i++)
        {
            key = weights.get_key_at_index(i);
            if (key >= key_star)
                ptr_probs[i] = key / s_gt_eps;
            else
                ptr_probs[i] = eps;
        }
    }

    return probs;
}