#ifndef UNIFORM_SAMPLER_H
#define UNIFORM_SAMPLER_H

#include <vector>

#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>

#include "globals.hpp"

namespace py = pybind11;

class UniformSampler
{
public:
    // attributes
    size_t N;
    std::vector<size_t> indices;

    // constructor
    UniformSampler(size_t N);

    // core
    void sample(py::array_t<float64> uniforms,
                py::array_t<int64> sampled_indices);
    py::array_t<float64> get_probs();
};

#endif