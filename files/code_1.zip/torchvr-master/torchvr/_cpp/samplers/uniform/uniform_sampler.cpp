#include <vector>

#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>

#include "globals.hpp"
#include "uniform_sampler.hpp"

// constructor
UniformSampler::UniformSampler(size_t N)
    : N{N}
{
    indices.reserve(N);
    for (size_t i = 0; i < N; ++i)
        indices[i] = i;
}

// sample
void UniformSampler::sample(py::array_t<float64> uniforms,
                            py::array_t<int64> sampled_indices)
{
    // reads the buffer info of the arrays
    py::buffer_info buf_uniforms = uniforms.request();
    py::buffer_info buf_sampled_indices = sampled_indices.request();

    // obtains pointers to the arrays
    float64 *ptr_uniforms = (float64 *)buf_uniforms.ptr;
    int64 *ptr_sampled_indices = (int64 *)buf_sampled_indices.ptr;

    // initializes local variables needed for algorithm
    size_t max = N;
    size_t index_in_indices;
    size_t sampled_index;

    // populate the sampled_indices array
    for (size_t i = 0; i < buf_uniforms.size; i++)
    {
        // finds the sampled index
        index_in_indices = (size_t)(ptr_uniforms[i] * max);
        sampled_index = indices[index_in_indices];
        ptr_sampled_indices[i] = sampled_index;

        // hides the sampled index at the end of the array
        indices[index_in_indices] = indices[max - 1];
        indices[max - 1] = sampled_index;
        max -= 1;
    }
}
py::array_t<float64> UniformSampler::get_probs()
{
    // creates an array holding the results
    py::array_t<float64> probs = py::array_t<float64>(N);

    // gets a pointer to the data
    py::buffer_info buf_probs = probs.request();
    float64 *ptr_probs = (float64 *)buf_probs.ptr;

    // computes and returns the probabilities
    float64 inv_N = 1 / (float64)N;
    for (size_t i = 0; i < buf_probs.size; i++)
        ptr_probs[i] = inv_N;
    return probs;
}