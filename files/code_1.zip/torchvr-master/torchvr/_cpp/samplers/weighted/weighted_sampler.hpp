#ifndef WEIGHTED_SAMPLER_H
#define WEIGHTED_SAMPLER_H

#include <vector>

#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>

#include "globals.hpp"
#include "bit.hpp"

namespace py = pybind11;

class WeightedSampler
{
public:
    // attributes
    size_t N;
    BIT weights;

    // constructor
    WeightedSampler(size_t N);
    WeightedSampler(py::array_t<float64> init_weights);

    // core
    void update(py::array_t<int64> indices,
                py::array_t<float64> new_weights,
                int64 mode);
    void sample(py::array_t<float64> uniforms,
                py::array_t<int64> sampled_indices,
                py::array_t<float64> sampled_probs,
                bool replace);
    py::array_t<float64> get_probs();
};

#endif