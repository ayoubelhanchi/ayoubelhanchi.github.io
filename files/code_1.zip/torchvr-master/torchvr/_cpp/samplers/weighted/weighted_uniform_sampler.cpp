#include <vector>

#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>

#include "globals.hpp"
#include "bit.hpp"
#include "weighted_uniform_sampler.hpp"

// constructors
WeightedUniformSampler::WeightedUniformSampler(size_t N)
    : N{N},
      weights(N) {}

WeightedUniformSampler::WeightedUniformSampler(py::array_t<float64> init_weights)
    : N{init_weights.size()},
      weights(init_weights.size())
{
    // reads the buffer info of the array
    py::buffer_info buf_init_weights = init_weights.request();

    // obtains pointer to the array
    float64 *ptr_init_weights = (float64 *)buf_init_weights.ptr;

    // initializes the weights
    for (size_t i = 0; i < buf_init_weights.size; ++i)
    {
        weights.set_value_at_index(i, ptr_init_weights[i]);
    }
}

// core
void WeightedUniformSampler::update(py::array_t<int64> indices,
                                    py::array_t<float64> new_weights,
                                    int64 mode)
{
    // reads the buffer info of the arrays
    py::buffer_info buf_indices = indices.request();
    py::buffer_info buf_new_weights = new_weights.request();

    // obtains pointers to the arrays
    int64 *ptr_indices = (int64 *)buf_indices.ptr;
    float64 *ptr_new_weights = (float64 *)buf_new_weights.ptr;

    // updates the new weights in the given indices using the mode passed
    // 0 is set, 1 is increment, 2 is multiply, 3 is increment square
    switch (mode)
    {
    case 0:
        for (size_t i = 0; i < buf_indices.size; ++i)
            weights.set_value_at_index(ptr_indices[i],
                                       ptr_new_weights[i]);
        break;
    case 1:
        for (size_t i = 0; i < buf_indices.size; ++i)
            weights.increment_value_at_index(ptr_indices[i],
                                             ptr_new_weights[i]);
        break;
    case 2:
        for (size_t i = 0; i < buf_indices.size; ++i)
            weights.multiply_value_at_index(ptr_indices[i],
                                            ptr_new_weights[i]);
        break;
    case 3:
        for (size_t i = 0; i < buf_indices.size; ++i)
            weights.increment_sqr_value_at_index(ptr_indices[i],
                                                 ptr_new_weights[i]);
        break;
    }
}
void WeightedUniformSampler::sample(py::array_t<bool> bernoullis,
                                    py::array_t<float64> uniforms,
                                    py::array_t<int64> sampled_indices,
                                    py::array_t<float64> sampled_probs,
                                    float64 p_mix) // p_mix is the prob to pick weighted component
{
    // reads the buffer info of the arrays
    py::buffer_info buf_bernoullis = bernoullis.request();
    py::buffer_info buf_uniforms = uniforms.request();
    py::buffer_info buf_sampled_indices = sampled_indices.request();
    py::buffer_info buf_sampled_probs = sampled_probs.request();

    // obtains pointers to the arrays
    bool *ptr_bernoullis = (bool *)buf_bernoullis.ptr;
    float64 *ptr_uniforms = (float64 *)buf_uniforms.ptr;
    int64 *ptr_sampled_indices = (int64 *)buf_sampled_indices.ptr;
    float64 *ptr_sampled_probs = (float64 *)buf_sampled_probs.ptr;

    // initializes local variables needed for algorithm
    float64 s = weights.get_sum_of_values();
    size_t sampled_index = 0;

    // samples from the mixture distribution
    for (size_t i = 0; i < buf_bernoullis.size; ++i)
    {
        // finds the sampled index
        if (ptr_bernoullis[i])
        {
            sampled_index = weights.select_cumsum(ptr_uniforms[i] * s);
        }
        else
        {
            sampled_index = (size_t)(ptr_uniforms[i] * N);
        }

        // assigns the sampled index and probability
        ptr_sampled_indices[i] = sampled_index;
        ptr_sampled_probs[i] =
            p_mix * (weights.get_value_at_index(sampled_index) / s) +
            (1.0 - p_mix) / (float64)N;
    }
}

py::array_t<float64> WeightedUniformSampler::get_probs(float64 p_mix)
{
    // creates an array holding the results
    py::array_t<float64> probs = py::array_t<float64>(N);

    // gets a pointer to the data
    py::buffer_info buf_probs = probs.request();
    float64 *ptr_probs = (float64 *)buf_probs.ptr;

    // computes and returns the probabilities
    float64 s = weights.get_sum_of_values();
    float64 inv_N = 1 / (float64)N;
    for (size_t i = 0; i < buf_probs.size; i++)
        ptr_probs[i] = p_mix * (weights.get_value_at_index(i) / s) +
                       (1.0 - p_mix) * inv_N;
    return probs;
}