#ifndef WEIGHTED_UNIFORM_SAMPLER_H
#define WEIGHTED_UNIFORM_SAMPLER_H

#include <vector>

#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>

#include "globals.hpp"
#include "bit.hpp"

namespace py = pybind11;

class WeightedUniformSampler
{
public:
    // attributes
    size_t N;    // number of elements
    BIT weights; // weights in BIT

    // constructor
    WeightedUniformSampler(size_t N);
    WeightedUniformSampler(py::array_t<float64> init_weights);

    // core
    void update(py::array_t<int64> indices,
                py::array_t<float64> new_weights,
                int64 mode);
    void sample(py::array_t<bool> bernoullis,
                py::array_t<float64> uniforms,
                py::array_t<int64> sampled_indices,
                py::array_t<float64> sampled_probs,
                float64 p_mix);
    py::array_t<float64> get_probs(float64 p_mix);
};

#endif