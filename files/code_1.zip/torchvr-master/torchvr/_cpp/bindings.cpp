#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>

#include "globals.hpp"
#include "bit.hpp"
#include "node.hpp"
#include "tree.hpp"
#include "uniform_sampler.hpp"
#include "weighted_sampler.hpp"
#include "weighted_uniform_sampler.hpp"
#include "optimal_sampler.hpp"

namespace py = pybind11;

PYBIND11_MODULE(_cpp, m)
{
     // binds binary indexeted tree
     py::class_<BIT>(m, "BIT")
         .def(py::init<size_t>())
         .def("get_sum_of_values",
              &BIT::get_sum_of_values)
         .def("get_value_at_index",
              &BIT::get_value_at_index,
              py::arg("i"))
         .def("set_value_at_index",
              &BIT::set_value_at_index,
              py::arg("i"), py::arg("v"))
         .def("increment_value_at_index",
              &BIT::increment_value_at_index,
              py::arg("i"), py::arg("inc"))
         .def("multiply_value_at_index",
              &BIT::multiply_value_at_index,
              py::arg("i"), py::arg("fac"))
         .def("increment_sqr_value_at_index",
              &BIT::increment_sqr_value_at_index,
              py::arg("i"), py::arg("inc_sqr"))
         .def("cumsum",
              &BIT::cumsum,
              py::arg("i"))
         .def("select_cumsum",
              &BIT::select_cumsum,
              py::arg("u"))
         .def("hide",
              &BIT::hide,
              py::arg("i"))
         .def("unhide",
              &BIT::unhide,
              py::arg("i"));

     // binds augmented red black tree
     py::class_<Node>(m, "Node")
         .def(py::init())
         .def_readonly("key", &Node::key)
         .def_readonly("data", &Node::data)
         .def("hide",
              &Node::hide,
              py::arg("NIL"))
         .def("unhide",
              &Node::unhide,
              py::arg("NIL"));

     py::class_<Tree>(m, "Tree")
         .def(py::init<size_t>())
         .def("in_order_walk",
              &Tree::in_order_walk,
              py::return_value_policy::reference)
         .def("get_sum_of_keys",
              &Tree::get_sum_of_keys)
         .def("get_key_at_index",
              &Tree::get_key_at_index,
              py::arg("i"))
         .def("set_key_at_index",
              &Tree::set_key_at_index,
              py::arg("i"), py::arg("k"))
         .def("select_right",
              &Tree::select_right,
              py::arg("r"),
              py::return_value_policy::reference)
         .def("select_left",
              &Tree::select_left,
              py::arg("r"),
              py::return_value_policy::reference)
         .def("right_rank",
              &Tree::right_rank,
              py::arg("i"))
         .def("left_rank",
              &Tree::left_rank,
              py::arg("i"))
         .def("select_right_cumsum",
              &Tree::select_right_cumsum,
              py::arg("u"),
              py::return_value_policy::reference)
         .def("select_left_cumsum",
              &Tree::select_left_cumsum,
              py::arg("u"),
              py::return_value_policy::reference)
         .def("right_cumsum",
              &Tree::right_cumsum,
              py::arg("i"))
         .def("left_cumsum",
              &Tree::left_cumsum,
              py::arg("i"))
         .def("hide",
              &Tree::hide,
              py::arg("i"))
         .def("unhide",
              &Tree::unhide,
              py::arg("i"));

     // binds uniform sampler
     py::class_<UniformSampler>(m, "UniformSampler")
         .def(py::init<size_t>(),
              py::arg("N"))
         .def("sample",
              &UniformSampler::sample,
              py::arg("uniforms"), py::arg("sampled_indices"))
         .def("get_probs",
              &UniformSampler::get_probs);

     // binds weighted sampler
     py::class_<WeightedSampler>(m, "WeightedSampler")
         .def(py::init<size_t>(),
              py::arg("N"))
         .def(py::init<py::array_t<float64>>(),
              py::arg("init_weights"))
         .def("update",
              &WeightedSampler::update,
              py::arg("indices"), py::arg("new_weights"), py::arg("mode"))
         .def("sample",
              &WeightedSampler::sample,
              py::arg("uniforms"), py::arg("sampled_indices"),
              py::arg("sampled_probs"), py::arg("replace"))
         .def("get_probs",
              &WeightedSampler::get_probs);

     // binds weighted uniform mixture sampler
     py::class_<WeightedUniformSampler>(m, "WeightedUniformSampler")
         .def(py::init<size_t>(),
              py::arg("N"))
         .def(py::init<py::array_t<float64>>(),
              py::arg("init_weights"))
         .def("update",
              &WeightedUniformSampler::update,
              py::arg("indices"), py::arg("new_weights"), py::arg("mode"))
         .def("sample",
              &WeightedUniformSampler::sample,
              py::arg("bernoullis"), py::arg("uniforms"),
              py::arg("sampled_indices"), py::arg("sampled_probs"),
              py::arg("p_mix"))
         .def("get_probs",
              &WeightedUniformSampler::get_probs,
              py::arg("p_mix"));

     // binds optimal sampler
     py::class_<OptimalSampler>(m, "OptimalSampler")
         .def(py::init<size_t>(),
              py::arg("N"))
         .def(py::init<py::array_t<float64>>(),
              py::arg("init_weights"))
         .def("update",
              &OptimalSampler::update,
              py::arg("indices"), py::arg("new_weights"))
         .def("sample",
              &OptimalSampler::sample,
              py::arg("uniforms"), py::arg("sampled_indices"),
              py::arg("sampled_probs"), py::arg("replace"),
              py::arg("eps"), py::arg("delete"))
         .def("solve",
              &OptimalSampler::solve,
              py::arg("eps"))
         .def("get_probs",
              &OptimalSampler::get_probs,
              py::arg("eps"));
}
