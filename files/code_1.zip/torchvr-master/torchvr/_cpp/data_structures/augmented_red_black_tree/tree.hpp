#ifndef TREE_H
#define TREE_H

#include <vector>

#include "globals.hpp"
#include "node.hpp"

class Tree
{
public:
    // attributes
    size_t size;
    size_t size_in_tree;
    std::vector<Node> nodes;
    Node *NIL;
    Node *root;

    // constructor
    Tree(size_t N);

    // helpers
    Node *minimum();
    Node *maximum();
    Node *search(float64 key);
    std::vector<Node *> in_order_walk();
    void _insert(Node *const z);
    void _delete(Node *const z);
    void _insert_fixup(Node *const z);
    void _delete_fixup(Node *const x);
    void _transplant(Node *const u, Node *const v);
    void _left_rotate(Node *const x);
    void _right_rotate(Node *const y);

    // core
    float64 get_sum_of_keys() { return root->sum; }
    float64 get_key_at_index(size_t i) { return nodes[i].key; }
    void set_key_at_index(size_t i, float64 k);
    size_t select_right(size_t r);
    size_t select_left(size_t r);
    size_t right_rank(size_t i);
    size_t left_rank(size_t i);
    size_t select_right_cumsum(float64 u);
    size_t select_left_cumsum(float64 u);
    float64 right_cumsum(size_t i);
    float64 left_cumsum(size_t i);
    void hide(size_t i) { nodes[i].hide(NIL); };
    void unhide(size_t i) { nodes[i].unhide(NIL); };
};

#endif