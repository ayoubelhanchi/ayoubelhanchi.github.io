#include "globals.hpp"
#include "node.hpp"

// static attribute used in initialization
size_t Node::num_of_nodes = 0;

// constructor
Node::Node() : data{num_of_nodes++} {}

// successor
Node *Node::successor(Node *const NIL)
{
    if (in_tree)
    {
        Node *x = this;
        Node *y = NIL;

        if (x->right != NIL)
        {
            y = x->right;
            while (y->left != NIL)
                y = y->left;
            return y;
        }

        y = x->p;
        while (y != NIL && x == y->right)
        {
            x = y;
            y = y->p;
        }
        return y;
    }
    else
        return NIL;
}

// predecessor
Node *Node::predecessor(Node *const NIL)
{
    if (in_tree)
    {
        Node *x = this;
        Node *y = NIL;

        if (x->left != NIL)
        {
            y = x->left;
            while (y->right != NIL)
                y = y->right;
            return y;
        }

        y = x->p;
        while (y != NIL && x == y->left)
        {
            x = y;
            y = y->p;
        }
        return y;
    }
    else
        return NIL;
}

// update_after_deletion
void Node::update_after_deletion(Node *const root)
{
    Node *y = p;
    while (y != root->p)
    {
        y->size -= 1;
        y->sum -= key;
        y = y->p;
    }
}

//hide
void Node::hide(Node *const NIL)
{
    if (in_tree)
    {
        if (hidden)
            return;

        Node *y = this;
        while (y != NIL)
        {
            y->size -= 1;
            y->sum -= key;
            y = y->p;
        }
        hidden = true;
    }
}

//unhide
void Node::unhide(Node *const NIL)
{
    if (in_tree)
    {
        if (!hidden)
            return;

        Node *y = this;
        while (y != NIL)
        {
            y->size += 1;
            y->sum += key;
            y = y->p;
        }
        hidden = false;
    }
}
