#include <vector>
#include <stack>
#include <cstddef> //for nullptr

#include "globals.hpp"
#include "node.hpp"
#include "tree.hpp"

// constructor
Tree::Tree(size_t size)
    : size{size},
      size_in_tree{0},
      nodes(size + 1),     // one extra space for NIL
      NIL{&(nodes[size])}, // NIL points to the last element
      root{NIL}            // initializes the root to NIL
{
    Node::num_of_nodes = 0; // sets node counter back to 0
}

// helpers
Node *Tree::minimum()
{
    Node *x = root;
    if (x == NIL)
        return x;
    while (x->left != NIL)
        x = x->left;
    return x;
}
Node *Tree::maximum()
{
    Node *x = root;
    if (x == NIL)
        return x;
    while (x->right != NIL)
        x = x->right;
    return x;
}
Node *Tree::search(float64 key)
{
    Node *x = root;
    while (key != x->key and x != NIL)
    {
        if (key < x->key)
            x = x->left;
        else
            x = x->right;
    }
    return x;
}
std::vector<Node *> Tree::in_order_walk()
{
    Node *x = root;
    if (x == NIL)
        return {};

    std::vector<Node *> ordered_nodes;
    ordered_nodes.reserve(size);
    std::stack<Node *> s;
    while (!s.empty() || x != NIL)
    {
        if (x != NIL)
        {
            s.push(x);
            x = x->left;
        }
        else
        {
            x = s.top();
            s.pop();
            if (!x->hidden)
                ordered_nodes.push_back(x);
            x = x->right;
        }
    }
    return ordered_nodes;
}
void Tree::_insert(Node *const z) // assumes z has key and data already set
{
    // finds z's parent
    Node *y = NIL;  // the eventual parent of z
    Node *x = root; // a dummy variable that guides y
    while (x != NIL)
    {
        y = x;
        y->size += 1;     // increments the size of subtrees containing z
        y->sum += z->key; // increments the sum of subtrees containing z
        if (z->key < x->key)
            x = x->left;
        else
            x = x->right;
    }

    // inserts z
    z->p = y;
    if (y == NIL) // the tree is empty
        root = z;
    else
    {
        if (z->key < y->key) // z should be inserted on the left of y
            y->left = z;
        else
            y->right = z; // z should be inserted on the right of y
    }

    // sets the attriutes of z
    z->left = NIL;
    z->right = NIL;
    z->color = RED;

    z->size = 1;
    z->sum = z->key;
    z->hidden = false;
    z->in_tree = true;

    // fixes up the tree after insertion
    _insert_fixup(z);

    // increases the count of number of elements in the tree
    size_in_tree += 1;
}
void Tree::_delete(Node *const z) // assumes z is in the tree and not hidden
{
    Node *y;
    bool y_og_color;
    Node *x;

    if (z->left == NIL)
    {
        y = z;
        y_og_color = y->color;
        y->update_after_deletion(root);
        x = z->right;
        _transplant(z, z->right);
    }
    else
    {
        if (z->right == NIL)
        {
            y = z;
            y_og_color = y->color;
            y->update_after_deletion(root);
            x = z->left;
            _transplant(z, z->left);
        }
        else
        {
            y = z->successor(NIL);
            y_og_color = y->color;
            z->update_after_deletion(root);
            y->update_after_deletion(z->right);
            y->size = z->size - 1;
            y->sum = z->sum - z->key;
            x = y->right;
            if (y->p == z)
                x->p = y;
            else
            {
                _transplant(y, y->right);
                y->right = z->right;
                y->right->p = y;
            }
            _transplant(z, y);
            y->left = z->left;
            y->left->p = y;
            y->color = z->color;
        }
    }
    if (y_og_color == BLACK)
        _delete_fixup(x);

    // resets the attributes of z
    // z->key = 0.0; do not set key to 0 here
    // in case we want to increment instead of replace
    z->key = 0.0;

    z->p = nullptr;
    z->left = nullptr;
    z->right = nullptr;
    z->color = BLACK;

    z->size = 0;
    z->sum = 0.0;
    z->hidden = false;
    z->in_tree = false;

    // decreases the count of number of elements in the tree
    size_in_tree -= 1;
}
void Tree::_insert_fixup(Node *const z)
{
    Node *y;
    Node *x = z;

    while (x->p->color == RED)
    {
        if (x->p == x->p->p->left)
        {
            y = x->p->p->right;
            if (y->color == RED)
            {
                x->p->color = BLACK;
                y->color = BLACK;
                x->p->p->color = RED;
                x = x->p->p;
            }
            else
            {
                if (x == x->p->right)
                {
                    x = x->p;
                    _left_rotate(x);
                }
                x->p->color = BLACK;
                x->p->p->color = RED;
                _right_rotate(x->p->p);
            }
        }
        else
        {
            y = x->p->p->left;
            if (y->color == RED)
            {
                x->p->color = BLACK;
                y->color = BLACK;
                x->p->p->color = RED;
                x = x->p->p;
            }
            else
            {
                if (x == x->p->left)
                {
                    x = x->p;
                    _right_rotate(x);
                }
                x->p->color = BLACK;
                x->p->p->color = RED;
                _left_rotate(x->p->p);
            }
        }
    }
    root->color = BLACK;
}
void Tree::_delete_fixup(Node *const x)
{
    Node *w;
    Node *u = x;

    while (u != root && u->color == BLACK)
    {
        if (u == u->p->left)
        {
            w = u->p->right;
            if (w->color == RED)
            {
                w->color = BLACK;
                u->p->color = RED;
                _left_rotate(u->p);
                w = u->p->right;
            }
            if (w->left->color == BLACK && w->right->color == BLACK)
            {
                w->color = RED;
                u = u->p;
            }
            else
            {
                if (w->right->color == BLACK)
                {
                    w->left->color = BLACK;
                    w->color = RED;
                    _right_rotate(w);
                    w = u->p->right;
                }
                w->color = u->p->color;
                u->p->color = BLACK;
                w->right->color = BLACK;
                _left_rotate(u->p);
                u = root;
            }
        }
        else
        {
            w = u->p->left;
            if (w->color == RED)
            {
                w->color = BLACK;
                u->p->color = RED;
                _right_rotate(u->p);
                w = u->p->left;
            }
            if (w->right->color == BLACK && w->left->color == BLACK)
            {
                w->color = RED;
                u = u->p;
            }
            else
            {
                if (w->left->color == BLACK)
                {
                    w->right->color = BLACK;
                    w->color = RED;
                    _left_rotate(w);
                    w = u->p->left;
                }
                w->color = u->p->color;
                u->p->color = BLACK;
                w->left->color = BLACK;
                _right_rotate(u->p);
                u = root;
            }
        }
    }
    u->color = BLACK;
}
void Tree::_transplant(Node *const u, Node *const v)
{
    if (u->p == NIL)
        root = v;
    else
    {
        if (u == u->p->left)
            u->p->left = v;
        else
            u->p->right = v;
    }
    v->p = u->p;
}
void Tree::_left_rotate(Node *const x)
{
    Node *y = x->right;

    x->right = y->left;
    if (y->left != NIL)
        y->left->p = x;

    y->p = x->p;
    if (x->p == NIL)
        root = y;
    else
    {
        if (x == x->p->left)
            x->p->left = y;
        else
            x->p->right = y;
    }

    y->left = x;
    x->p = y;

    y->size = x->size;
    x->size = x->left->size + x->right->size + 1;

    y->sum = x->sum;
    x->sum = x->left->sum + x->right->sum + x->key;
}
void Tree::_right_rotate(Node *y)
{
    Node *x = y->left;

    y->left = x->right;
    if (x->right != NIL)
        x->right->p = y;

    x->p = y->p;
    if (y->p == NIL)
        root = x;
    else
    {
        if (y == y->p->left)
            y->p->left = x;
        else
            y->p->right = x;
    }

    x->right = y;
    y->p = x;

    x->size = y->size;
    y->size = y->left->size + y->right->size + 1;

    x->sum = y->sum;
    y->sum = y->left->sum + y->right->sum + y->key;
}

// core
void Tree::set_key_at_index(size_t i, float64 k)
{
    Node *z = &(nodes[i]);
    if (z->in_tree)
    {
        if (z->hidden)
            z->unhide(NIL);
        _delete(z);
    }
    z->key = k;
    _insert(z);
}
size_t Tree::select_right(size_t rank)
{
    Node *x = root;
    size_t r;
    while (true)
    {
        r = x->right->size + 1;
        if (x->hidden)
            r -= 1;
        if (rank == r)
        {
            if (x->hidden)
                x = x->right;
            else
                return x->data;
        }
        else
        {
            if (rank < r)
                x = x->right;
            else
            {
                rank -= r;
                x = x->left;
            }
        }
    }
}
size_t Tree::select_left(size_t rank)
{
    Node *x = root;
    size_t r;
    while (true)
    {
        r = x->left->size + 1;
        if (x->hidden)
            r -= 1;
        if (rank == r)
        {
            if (x->hidden)
                x = x->left;
            else
                return x->data;
        }
        else
        {
            if (rank < r)
                x = x->left;
            else
            {
                rank -= r;
                x = x->right;
            }
        }
    }
}
size_t Tree::right_rank(size_t i) // nodes[i] is assumed to not be hidden
{
    Node *x = &nodes[i];
    size_t r = x->right->size + 1;
    Node *y = x;
    while (y != root)
    {
        if (y == y->p->left)
        {
            r = r + y->p->right->size + 1;
            if (y->p->hidden)
                r -= 1;
        }
        y = y->p;
    }
    return r;
}
size_t Tree::left_rank(size_t i) // nodes[i] is assumed to not be hidden
{
    Node *x = &nodes[i];
    size_t r = x->left->size + 1;
    Node *y = x;
    while (y != root)
    {
        if (y == y->p->right)
        {
            r = r + y->p->left->size + 1;
            if (y->p->hidden)
                r -= 1;
        }
        y = y->p;
    }
    return r;
}
size_t Tree::select_right_cumsum(float64 u)
{
    Node *x = root;
    float64 right_endpoint;
    float64 left_endpoint;
    while (true)
    {
        right_endpoint = x->right->sum + x->key;
        if (x->hidden)
            right_endpoint -= x->key;
        left_endpoint = x->right->sum;

        if (u >= left_endpoint && u < right_endpoint)
            return x->data;
        else
        {
            if (u >= right_endpoint)
            {
                u -= right_endpoint;
                x = x->left;
            }
            else
                x = x->right;
        }
    }
}
size_t Tree::select_left_cumsum(float64 u)
{
    Node *x = root;
    float64 right_endpoint;
    float64 left_endpoint;
    while (true)
    {
        right_endpoint = x->left->sum + x->key;
        if (x->hidden)
            right_endpoint -= x->key;
        left_endpoint = x->left->sum;

        if (u >= left_endpoint && u < right_endpoint)
            return x->data;
        else
        {
            if (u > right_endpoint)
            {
                u -= right_endpoint;
                x = x->right;
            }
            else
                x = x->left;
        }
    }
}
float64 Tree::right_cumsum(size_t i) // nodes[i] is assumed to not be hidden
{
    Node *x = &nodes[i];
    float64 s = x->right->sum + x->key;
    Node *y = x;
    while (y != root)
    {
        if (y == y->p->left)
        {
            s = s + y->p->right->sum + y->p->key;
            if (y->p->hidden)
                s -= y->p->key;
        }
        y = y->p;
    }
    return s;
}
float64 Tree::left_cumsum(size_t i) // nodes[i] is assumed to not be hidden
{
    Node *x = &nodes[i];
    float64 s = x->left->sum + x->key;
    Node *y = x;
    while (y != root)
    {
        if (y == y->p->right)
        {
            s = s + y->p->left->sum + y->p->key;
            if (y->p->hidden)
                s -= y->p->key;
        }
        y = y->p;
    }
    return s;
}
