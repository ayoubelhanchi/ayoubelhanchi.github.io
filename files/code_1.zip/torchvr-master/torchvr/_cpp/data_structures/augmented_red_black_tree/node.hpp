#ifndef NODE_H
#define NODE_H

#include <cstddef> //for nullptr

#include "globals.hpp"

#define BLACK true
#define RED false

class Node
{
public:
    // static attribute for default constructor
    static size_t num_of_nodes;

    // attributes
    float64 key = 0.0;
    size_t data;

    Node *p = nullptr;
    Node *left = nullptr;
    Node *right = nullptr;
    bool color = BLACK;

    size_t size = 0;
    float64 sum = 0.0;
    bool hidden = false;
    bool in_tree = false;

    // core
    Node(); // default constructor
    Node *successor(Node *const NIL);
    Node *predecessor(Node *const NIL);
    void update_after_deletion(Node *const root);
    void hide(Node *const NIL);
    void unhide(Node *const NIL);
};

#endif