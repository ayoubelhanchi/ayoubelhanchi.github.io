#include <vector>
#include <cmath>
#include <string>
#include <stdexcept>
/*#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
namespace py = pybind11; */

#include "globals.hpp"
#include "bit.hpp"

// constructor
BIT::BIT(size_t size)
    : size{size},
      start{noa(size) + 1},
      nodes(1 + noa(size) + size, 0.0),
      hidden(size, false) {}

// core
void BIT::set_value_at_index(size_t i, float64 v) // assumes i is not hidden
{
    size_t j = a2t(i);
    float64 inc = v - nodes[j];
    while (j != NIL)
    {
        nodes[j] += inc;
        j = p(j);
    }
}
void BIT::increment_value_at_index(size_t i, float64 inc) // assumes i is not hidden
{
    size_t j = a2t(i);
    while (j != NIL)
    {
        nodes[j] += inc;
        j = p(j);
    }
}
void BIT::multiply_value_at_index(size_t i, float64 fac)
{
    size_t j = a2t(i);
    float64 inc = (fac - 1.0) * nodes[j];
    while (j != NIL)
    {
        nodes[j] += inc;
        j = p(j);
    }
}
void BIT::increment_sqr_value_at_index(size_t i, float64 inc_sqr)
{
    size_t j = a2t(i);
    float64 inc = std::sqrt(inc_sqr + std::pow(nodes[j], 2)) - nodes[j];
    while (j != NIL)
    {
        nodes[j] += inc;
        j = p(j);
    }
}
float64 BIT::cumsum(size_t i) // assumes i is not hidden
{
    size_t j = a2t(i);
    float64 s = nodes[j];
    while (j != root)
    {
        if (j == right(p(j)))
            s += nodes[left(p(j))];
        j = p(j);
    }
    return s;
}
size_t BIT::select_cumsum(float64 u)
{
    size_t j = root;
    while (!is_leaf(j))
    {
        if (u >= nodes[left(j)])
        {
            u -= nodes[left(j)];
            j = right(j);
        }
        else
            j = left(j);
    }
    size_t i = t2a(j);
    if (hidden[i])
        i = t2a(right(p(a2t(i))));
    return i;
}

void BIT::hide(size_t i)
{
    if (hidden[i])
        return;
    size_t j = a2t(i);
    float64 inc = -nodes[j];
    j = p(j);
    while (j != NIL)
    {
        nodes[j] += inc;
        j = p(j);
    }
    hidden[i] = true;
}

void BIT::unhide(size_t i)
{
    if (!hidden[i])
        return;
    size_t j = a2t(i);
    float64 inc = nodes[j];
    j = p(j);
    while (j != NIL)
    {
        nodes[j] += inc;
        j = p(j);
    }
    hidden[i] = false;
}

/*// syntactic sugar
py::int_ BIT::__len__()
{
    return py::cast(size);
}
py::str BIT::__repr__()
{
    std::string repr;
    repr.reserve(18 * size + 21);
    repr.append("BinaryIndexedTree([");
    std::string tmp;
    for (size_t i = 0; i < size; ++i)
    {
        tmp = std::to_string(nodes[a2t(i)]);
        if (tmp.find('.') != std::string::npos)
        {
            tmp = tmp.substr(0, tmp.find_last_not_of('0') + 1);
            if (tmp.find('.') == tmp.size() - 1)
                tmp = tmp.append("0");
        }
        repr.append(tmp);
        if (i != size - 1)
            repr.append(", ");
    }
    repr.append("])");
    return py::cast(repr);
}
py::float_ BIT::__getitem__(py::int_ index)
{
    if (index < 0)
        throw std::out_of_range("negative indices not supported.");
    return py::cast(get_value_at_index(index.cast<size_t>()));
}
py::list BIT::__getitem__(py::slice slice)
{
    size_t start, stop, step, slicelength;
    if (!slice.compute(size, &start, &stop, &step, &slicelength))
        throw py::error_already_set();

    py::list values(slicelength);
    for (size_t i = start, j = 0;
         i < slicelength && j < values.size();
         i += step, j++)
        values[j] = get_value_at_index(i);
    return values;
}
py::list BIT::__getitem__(py::list indices)
{
    py::list values(indices.size());
    for (size_t i = 0; i < indices.size(); ++i)
    {
        if (indices[i].cast<int64>() < 0)
            throw std::out_of_range("negative indices not supported.");
        values[i] = get_value_at_index(indices[i].cast<size_t>());
    }
    return values;
}
void BIT::__setitem__(py::int_ index, py::float_ value)
{
    if (index < 0)
        throw std::out_of_range("negative indices not supported.");
    set_value_at_index(value.cast<float64>(), index.cast<size_t>());
}
void BIT::__setitem__(py::slice slice, py::list values)
{
    size_t start, stop, step, slicelength;
    if (!slice.compute(size, &start, &stop, &step, &slicelength))
        throw py::error_already_set();

    if (slicelength != values.size())
        throw std::invalid_argument("slice length and length of "
                                    "argument 'values' "
                                    "must be equal.");

    for (size_t i = start, j = 0;
         i < slicelength && j < values.size();
         i += step, j++)
        set_value_at_index(values[j].cast<float64>(), i);
}
void BIT::__setitem__(py::list indices, py::list values)
{
    if (values.size() != indices.size())
        throw std::invalid_argument("arguments 'values' and 'indices' "
                                    "must have the same size.");
    for (size_t i = 0; i < values.size(); ++i)
    {
        if (indices[i].cast<int64>() < 0)
            throw std::out_of_range("negative indices not supported.");
        set_value_at_index(values[i].cast<float64>(), indices[i].cast<size_t>());
    }
}
py::array_t<float64> BIT::__getitem__(py::array_t<int64> indices)
{
    // reads the buffer info of the indices array
    py::buffer_info buf_indices = indices.request();
    if (buf_indices.ndim != 1)
        throw std::invalid_argument("Number of dimensions of array "
                                    "'indices' must be one.");

    // creates a new numpy array holding the values array
    py::array_t<float64> values(buf_indices.size);
    py::buffer_info buf_values = values.request();

    // obtains pointers to the data in both arrays
    int64 *ptr_indices = (int64 *)buf_indices.ptr;
    float64 *ptr_values = (float64 *)buf_values.ptr;

    // fills the values array
    for (size_t i = 0; i < buf_indices.size; i++)
    {
        if (ptr_indices[i] < 0)
            throw std::out_of_range("negative indices not supported.");
        ptr_values[i] = get_value_at_index((size_t)ptr_indices[i]);
    }

    // return the values
    return values;
}
void BIT::__setitem__(py::array_t<int64> indices, py::array_t<float64> values)
{
    // reads the buffer info of the indices and values arrays
    py::buffer_info buf_indices = indices.request();
    py::buffer_info buf_values = values.request();

    // checks dimension and size
    if (buf_indices.ndim != 1 || buf_values.ndim != 1)
        throw std::invalid_argument("Number of dimensions of arrays "
                                    "'indices' and 'values' must be one.");
    if (buf_indices.size != buf_values.size)
        throw std::invalid_argument("Size of the arrays 'indices' and "
                                    "'values' must be the same.");

    // obtains pointers to the data in both arrays
    int64 *ptr_indices = (int64 *)buf_indices.ptr;
    float64 *ptr_values = (float64 *)buf_values.ptr;

    // set the values in indices
    for (size_t i = 0; i < buf_indices.size; i++)
    {
        if (ptr_indices[i] < 0)
            throw std::out_of_range("negative indices not supported.");
        set_value_at_index(ptr_indices[i], ptr_values[i]);
    }
}
*/