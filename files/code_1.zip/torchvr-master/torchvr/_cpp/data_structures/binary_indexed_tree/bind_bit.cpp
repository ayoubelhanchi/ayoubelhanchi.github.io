#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>

#include "../../globals.hpp"
#include "bit.hpp"

namespace py = pybind11;
template <typename... Args>
using overload_cast_ = pybind11::detail::overload_cast_impl<Args...>;

PYBIND11_MODULE(bit, m)
{
     py::class_<BIT>(m, "BIT")
         .def(py::init<uint64>(),
              py::arg("N"))
         .def("__len__",
              &BIT::__len__)
         .def("__repr__",
              &BIT::__repr__)
         .def("__getitem__",
              overload_cast_<py::int_>()(&BIT::__getitem__))
         /*.def("__getitem__",
             overload_cast_<py::slice>()(&BIT::__getitem__))
        .def("__getitem__",
             overload_cast_<py::list>()(&BIT::__getitem__))*/
         .def("__getitem__",
              overload_cast_<py::array_t<int64>>()(&BIT::__getitem__))
         /*.def("__setitem__",
             overload_cast_<py::int_, py::float_>()(&BIT::__setitem__))
        .def("__setitem__",
             overload_cast_<py::slice, py::list>()(&BIT::__setitem__))
        .def("__setitem__",
             overload_cast_<py::list, py::list>()(&BIT::__setitem__))*/
         .def("__setitem__",
              overload_cast_<py::array_t<int64>, py::array_t<float64>>()(&BIT::__setitem__));
}