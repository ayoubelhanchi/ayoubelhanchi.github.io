#ifndef BIT_H
#define BIT_H

#include <vector>
#include <cmath>

#include "globals.hpp"

class BIT
{
public:
    // attributes
    size_t size;
    size_t start;
    size_t const NIL = 0;
    size_t const root = 1;
    std::vector<float64> nodes;
    std::vector<bool> hidden;

    // constructor
    BIT(size_t size);
    // constructor helper, computes and returns the number of ancestors
    static size_t noa(size_t size)
    {
        size_t h = (size_t)std::ceil(std::log2(size)); // height of BIT
        size_t noa = (size_t)std::pow(2, h) - 1;       // number of ancestors
        return noa;
    }

    // helpers
    size_t p(size_t j) { return j / 2; };
    size_t left(size_t j) { return 2 * j; }
    size_t right(size_t j) { return 2 * j + 1; }
    size_t t2a(size_t j) { return j - start; }
    size_t a2t(size_t i) { return i + start; }
    size_t is_leaf(size_t j) { return (j >= start); }

    // core
    float64 get_sum_of_values() { return nodes[root]; }
    float64 get_value_at_index(size_t i) { return nodes[a2t(i)]; }
    void set_value_at_index(size_t i, float64 v);
    void increment_value_at_index(size_t i, float64 inc);
    void multiply_value_at_index(size_t i, float64 fac);
    void increment_sqr_value_at_index(size_t i, float64 inc_sqr);
    float64 cumsum(size_t i);
    size_t select_cumsum(float64 u);
    void hide(size_t i);
    void unhide(size_t i);

    /*// syntactic sugar
    py::int_ __len__();
    py::str __repr__();
    py::float_ __getitem__(py::int_ index);
    py::list __getitem__(py::slice indices);
    py::list __getitem__(py::list indices);
    py::array_t<float64> __getitem__(py::array_t<int64> indices);
    void __setitem__(py::int_ index, py::float_ value);
    void __setitem__(py::slice indices, py::list values);
    void __setitem__(py::list indices, py::list values);
    void __setitem__(py::array_t<int64> indices, py::array_t<float64> values);*/
};

#endif