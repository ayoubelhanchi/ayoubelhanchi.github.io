import torch
from .utils import (
    _grads_weight_conv2d,
    _grads_bias_conv2d,
    _grad_weight_linear,
    _grad_bias_linear
)


class _CvLayer:

    def __init__(self, layer, data, device, method):
        self._layer = layer

        self.N = len(data)
        self.device = device
        self.method = method
        for p in self.parameters():
            p.requires_grad = False
        self.requires_cv_grad = True

        self._input = None
        self._output_grad = None
        self._indices = None

        self._init_prev_grads()
        self._init_expected_prev_grad()

    def forward(self, input, indices=None):
        if torch.is_grad_enabled() and self.requires_cv_grad:
            self._check_requires_grad_conflict()
            self._check_indices(input, indices)
            self._indices = indices
            self._input = input.detach()  # detach from comp graph
        output = self._layer.forward(self, input)
        if torch.is_grad_enabled() and self.requires_cv_grad:
            output.requires_grad_()
            output.register_hook(self._cv_hook)
        return output

    def _check_requires_grad_conflict(self):
        if self.requires_cv_grad:
            for name, p in self.named_parameters():
                if p.requires_grad:
                    raise ValueError("The attributes 'requires_grad' of " +
                                     "the parameters and the attribute " +
                                     "'requires_cv_grad' of the layer " +
                                     "are mutually " +
                                     "exclusive. At most one of them can be " +
                                     "set to 'True' at the same time. " +
                                     "Parameter '{0}' ".format(name) +
                                     "has requires_grad=True, while " +
                                     "requires_cv_grad=True.")

    @staticmethod
    def _check_indices(input, indices):
        if indices is None:
            raise ValueError("argument 'indices' is required" +
                             "when 'requires_cv_grad=True'. " +
                             "argument 'indices' is None" +
                             "while requires_cv_grad=True")
        if type(indices) != torch.Tensor:
            raise TypeError("argument 'indices' must " +
                            "be a {0} not a {1}.".format(
                                torch.Tensor.__name__,
                                type(indices).__name__
                            ))
        if indices.shape != torch.Size([input.shape[0]]):
            raise ValueError("argument 'indices' should be a " +
                             "1-dimensional Tensor of the same " +
                             "length as the first dimension " +
                             "of argument 'input'. " +
                             "Received a Tensor of shape {0}".format(
                                list(indices.shape)
                             ))

    def _cv_hook(self, grad):
        self._output_grad = grad  # grad is already detached
        self._current_grad()
        self._prev_grad()
        self._cv_grad()
        self._update_prev_grads()
        self._update_expected_prev_grad()
        self._clean()

    def _init_prev_grads(self):
        raise NotImplementedError

    def _init_expected_prev_grad(self):
        for p in self.parameters():
            p._expected_prev_grad = torch.zeros_like(p)

    def _current_grad(self):
        raise NotImplementedError

    def _prev_grad(self):
        raise NotImplementedError

    def _cv_grad(self):
        for p in self.parameters():
            if self.method == 'SAGA':
                weight = self.N/len(self._indices)
                p.grad = weight * p._current_grad + (p._expected_prev_grad -
                                                     weight * p._prev_grad)
            else:  # self.method == 'SAG'
                p.grad = p._current_grad + (p._expected_prev_grad -
                                            p._prev_grad)

    def _update_prev_grads(self):
        raise NotImplementedError

    def _update_expected_prev_grad(self):
        # called only after both _prev_grad and _update_prev_grads have
        # been called (in that order).
        for p in self.parameters():
            p._expected_prev_grad -= p._prev_grad
        self._prev_grad()  # get the newly stored gradients
        for p in self.parameters():
            p._expected_prev_grad += p._prev_grad

    def _clean(self):
        self._input = None
        self._output_grad = None
        self._indices = None
        for p in self.parameters():
            del p._current_grad
            del p._prev_grad


class CvLinear(_CvLayer, torch.nn.Linear):
    """Subclass of torch.nn.Linear that implements the control-variate based
    variance reduction methods 'SAG' and 'SAGA'. The variance-reduced
    gradient estimate is automatically assigned to the 'grad' attribute
    of the parameters during the backward pass.

    Arguments:
        - data (torch.utils.data.Dataset): the training data.
        - device (torch.device, optional): The device used for the
        storage of the previously seen gradients. If None, uses the
        current device for the default tensor type. Default: None.
        - method (str, optional): The control variate method to use.
        One of ['SAGA', 'SAG'].

    References::
        - Aaron Defazio, Francis Bach, and Simon Lacoste-Julien, SAGA: A Fast
            Incremental Gradient Method With Support for Non-Strongly
            Convex Composite Objectives,
            arXiv:1407.0202 [cs.LG], 2014 (available at
            https://arxiv.org/abs/1407.0202).

        - Mark Schmidt, Nicolas Le Roux and Francis Bach, Minimizing
            Finite Sums with the Stochastic Average Gradient,
            arXiv:1309.2388 [math.OC], 2013 (available at
            https://arxiv.org/abs/1309.2388).
    """

    def __init__(self, data, in_features, out_features, bias=True,
                 device=None, method="SAGA"):
        torch.nn.Linear.__init__(self, in_features, out_features, bias)
        _CvLayer.__init__(self, torch.nn.Linear, data, device, method)

    def _init_prev_grads(self):
        self._prev_input = torch.zeros(self.N, self.in_features,
                                       device=self.device)
        self._prev_output_grad = torch.zeros(self.N, self.out_features,
                                             device=self.device)

    def _current_grad(self):
        self.weight._current_grad = _grad_weight_linear(self._input,
                                                        self._output_grad)
        if self.bias is not None:
            self.bias._current_grad = _grad_bias_linear(self._output_grad)

    def _prev_grad(self):
        self.weight._prev_grad = \
            _grad_weight_linear(self._prev_input[self._indices],
                                self._prev_output_grad[self._indices])

        if self.bias is not None:
            self.bias._prev_grad = \
                _grad_bias_linear(self._prev_output_grad[self._indices])

    def _update_prev_grads(self):
        self._prev_input[self._indices] = self._input
        self._prev_output_grad[self._indices] = self._output_grad


class CvConv2d(_CvLayer, torch.nn.Conv2d):
    """Subclass of torch.nn.Conv2d that implements the control-variate based
    variance reduction methods 'SAG' and 'SAGA'. The variance-reduced
    gradient estimate is automatically assigned to the 'grad' attribute
    of the parameters during the backward pass.

    Arguments:
        - data (torch.utils.data.Dataset): the training data.
        - device (torch.device, optional): The device used for the
        storage of the previously seen gradients. If None, uses the
        current device for the default tensor type. Default: None.
        - method (str, optional): The control variate method to use.
        One of ('SAGA', 'SAG').
        - rank (int, optional): The rank of the low-rank approximation
        of the previous gradients that is stored. If None, the exact
        previous gradients are stored. Default: None

    References::
        - Aaron Defazio, Francis Bach, and Simon Lacoste-Julien, SAGA: A Fast
            Incremental Gradient Method With Support for Non-Strongly
            Convex Composite Objectives,
            arXiv:1407.0202 [cs.LG], 2014 (available at
            https://arxiv.org/abs/1407.0202).

        - Mark Schmidt, Nicolas Le Roux and Francis Bach, Minimizing
            Finite Sums with the Stochastic Average Gradient,
            arXiv:1309.2388 [math.OC], 2013 (available at
            https://arxiv.org/abs/1309.2388).
    """

    def __init__(self, data, in_channels, out_channels, kernel_size,
                 stride=1, padding=0, dilation=1, bias=True,
                 device=None, method='SAGA', rank=None):
        torch.nn.Conv2d.__init__(self, in_channels, out_channels, kernel_size,
                                 stride, padding, dilation, bias=bias)
        _CvLayer.__init__(self, torch.nn.Conv2d, data, device, method)

        if rank is not None:
            if type(rank) != int:
                raise TypeError("argument 'rank' should be an" +
                                "'{0}' but received '{1}'".format(
                                    int.__name__,
                                    type(rank).__name__
                                ))
            if rank >= min(self.out_channels,
                           self.in_channels * self.kernel_size[0] *
                           self.kernel_size[1]):
                rank = None
        self.rank = rank

    def _init_prev_grads(self):
        if self.rank is None:
            self.weight._prev_grads = torch.zeros([self.N] +
                                                  list(self.weight.shape),
                                                  device=self.device)
        else:
            out_dim = self.out_channels
            in_dim = self.in_channels * self.kernel_size[0] *\
                self.kernel_size[1]
            self.weight._left_sv = torch.zeros([self.N, out_dim, self.rank],
                                               device=self.device)
            self.weight._sv = torch.zeros([self.N, self.rank])
            self.weight._right_sv = torch.zeros([self.N, in_dim, self.rank],
                                                device=self.device)
            self.weight._prev_grads_errors = torch.zeros(self.N)

        if self.bias is not None:
            self.bias._prev_grads = torch.zeros([self.N] +
                                                list(self.bias.shape))

    def _current_grad(self):
        self.weight._current_grads = \
            _grads_weight_conv2d(self._input, self._output_grad,
                                 self.kernel_size, self.dilation,
                                 self.padding, self.stride)
        self.weight._current_grad = self.weight._current_grads.sum(dim=0)
        if self.bias is not None:
            self.bias._current_grads = _grads_bias_conv2d(self._output_grad)
            self.bias._current_grad = self.bias._current_grads.sum(dim=0)

    def _prev_grad(self):
        if self.rank is None:
            self.weight._prev_grad = \
                self.weight._prev_grads[self._indices].sum(dim=0)
        else:
            self.weight._prev_grad = \
                (self.weight._left_sv[self._indices] *
                 self.weight._sv[self._indices].unsqueeze(1)) @ \
                self.weight._right_sv[self._indices].transpose(1, 2)
        if self.bias is not None:
            self.bias._prev_grad = \
                self.bias._prev_grads[self._indices].sum(dim=0)

    def _update_prev_grads(self):
        if self.rank is None:
            self.weight._prev_grads[self._indices] = self.weight._current_grads
        else:
            temp = torch.svd(self.weight._current_grads)
            self.weight._left_sv[self._indices] = temp[0][:, :, 0:self.rank]
            self.weight._sv[self._indices] = temp[1][:, 0:self.rank]
            self.weight._right_sv[self._indices] = temp[2][:, :, 0:self.rank]
            self.weight._prev_grads_errors[self._indices] = \
                temp[1][:, self.rank]
            del temp

        if self.bias is not None:
            self.bias._prev_grads[self._indices] = self.bias._current_grads

    def _clean(self):
        _CvLayer._clean(self)
        for p in self.parameters():
            del p._current_grads
