import torch
from .utils import (
    _grads_weight_linear,
    _grads_bias_linear,
    _grads_weight_conv2d,
    _grads_bias_conv2d,
    _norms_weight_linear,
    _norms_bias_linear,
    _weighted_grad_weight_linear,
    _weighted_grad_bias_linear
)


class _Layer:

    def __init__(self, layer, requires_grads,
                 requires_norms, requires_weighted_grad):
        self.requires_grads = requires_grads
        self.requires_norms = requires_norms
        self.requires_weighted_grad = requires_weighted_grad

        self._layer = layer

        self._input = None
        self._output_grad = None
        self._weights_grads = None

    def forward(self, input, weights_grads=None):
        if self._is_input_output_grad_needed():
            if self.requires_weighted_grad:
                self._check_weights_grads(input, weights_grads)
                self._weights_grads = weights_grads
            self._input = input.detach()  # detach from comp graph
        output = self._layer.forward(self, input)
        if self._is_input_output_grad_needed():
            output.requires_grad_()
            output.register_hook(self._hook)
        return output

    def _is_input_output_grad_needed(self):
        grad_enabled = torch.is_grad_enabled()
        grad_required = (self.requires_grads or
                         self.requires_norms or
                         self.requires_weighted_grad)
        return (grad_enabled and grad_required)

    @staticmethod
    def _check_weights_grads(input, weights_grads):
        if weights_grads is None:
            raise ValueError("weighted gradient required, " +
                             "but argument 'weights_grads' is None.")
        if type(weights_grads) != torch.Tensor:
            raise TypeError("argument 'weights_grads' must " +
                            "be a {0} not a {1}.".format(
                                torch.Tensor.__name__,
                                type(weights_grads).__name__
                            ))
        if weights_grads.shape != torch.Size([input.shape[0]]):
            raise ValueError("argument 'weights_grads' should be a " +
                             "one dimensional tensor of the same " +
                             "length as the first dimension " +
                             "of argument 'input'. " +
                             "Received a Tensor of shape {0}".format(
                                 list(weights_grads.shape)
                             ))

    def _hook(self, grad):
        self._output_grad = grad  # grad is already detached from comp graph
        if self.requires_grads:
            self._grads()
        if self.requires_norms:
            self._norms()
        if self.requires_weighted_grad:
            self._weighted_grad()
        self._clean()

    def _grads(self):
        raise NotImplementedError

    def _norms(self):
        raise NotImplementedError

    def _weighted_grad(self):
        raise NotImplementedError

    def _clean(self):
        self._input = None
        self._output_grad = None
        self._weights_grads = None


class Linear(_Layer, torch.nn.Linear):
    """Subclass of torch.nn.Linear providing the (optional) efficient
    computation during the backward pass of:
        - per-example gradients
        - weighted sum of the per-example gradients
        - Euclidean norm of the per-example gradients

    Arguments:
        __init__:
            - requires_grads (Boolean, optional): If True, the per-example
            gradients are computed during the backward pass and stored
            in the attribute "grads" of the parameters. Default: False.
            - requires_norms (Boolean, optional): If True, the Euclidean norm
            of the per-example gradients is computed and stored in the
            attribute "norms" of the parameters. Default: False.
            - requires_weighted_grad (Boolean, optional): If True, the weighted
            sum of the per-example gradients is computed and stored in the
            attribute "weighted_grad" of the parameters. The weights should
            be passed as an argument in the call to forward. Default: False.

        __call__:
            - weights_grads (Tensor): The weights of the
            per-example gradients if requires_weighted_grad is True,
            ignored otherwise. Default: None.
    """

    def __init__(self, in_features, out_features, bias=True,
                 requires_grads=False, requires_norms=False,
                 requires_weighted_grad=False):
        torch.nn.Linear.__init__(self, in_features, out_features, bias)
        _Layer.__init__(self, torch.nn.Linear, requires_grads,
                        requires_norms, requires_weighted_grad)

    # the forward call is correctly made through the forward method
    # of _Layer since it is the first in python's MRO order.

    def _grads(self):
        self.weight.grads = _grads_weight_linear(self._input,
                                                 self._output_grad)
        if self.bias is not None:
            self.bias.grads = _grads_bias_linear(self._output_grad)

    def _norms(self):
        self.weight.norms = _norms_weight_linear(self._input,
                                                 self._output_grad)
        if self.bias is not None:
            self.bias.norms = _norms_bias_linear(self._output_grad)

    def _weighted_grad(self):
        self.weight.weighted_grad = _weighted_grad_weight_linear(
            self._input, self._output_grad, self._weights_grads)
        if self.bias is not None:
            self.bias.weighted_grad = _weighted_grad_bias_linear(
                self._output_grad, self._weights_grads)


class Conv2d(_Layer, torch.nn.Conv2d):
    """Subclass of torch.nn.Conv2d providing the (optional) efficient
    computation during the backward pass of:
        - per-example gradients
        - weighted sum of the per-example gradients
        - Euclidean norm of the per-example gradients

    Arguments:
        __init__:
            - requires_grads (Boolean, optional): If True, the per-example
            gradients are computed during the backward pass and stored
            in the attribute "grads" of the parameters. Default: False.
            - requires_norms (Boolean, optional): If True, the Euclidean norm
            of the per-example gradients is computed and stored in the
            attribute "norms" of the parameters. Default: False.
            - requires_weighted_grad (Boolean, optional): If True, the weighted
            sum of the per-example gradients is computed and stored in the
            attribute "weighted_grad" of the parameters. The weights should
            be passed as an argument in the call to forward. Default: False.

        __call__:
            - weights_grads (Tensor): The weights of the
            per-example gradients if requires_weighted_grad is True,
            ignored otherwise. Default: None.
    """

    def __init__(self, in_channels, out_channels, kernel_size,
                 stride=1, padding=0, dilation=1, bias=True,
                 requires_grads=False, requires_norms=False,
                 requires_weighted_grad=False):
        torch.nn.Conv2d.__init__(self, in_channels, out_channels, kernel_size,
                                 stride, padding, dilation, bias=bias)
        _Layer.__init__(self, torch.nn.Conv2d, requires_grads,
                        requires_norms, requires_weighted_grad)
        self._grads_computed = False

    # the forward call is correctly made through the forward method
    # of _Layer since it is the first in python's MRO order.

    def _grads(self):
        self.weight.grads = _grads_weight_conv2d(self._input,
                                                 self._output_grad,
                                                 self.kernel_size,
                                                 self.dilation,
                                                 self.padding,
                                                 self.stride)
        if self.bias is not None:
            self.bias.grads = _grads_bias_conv2d(self._output_grad)
        self._grads_computed = True

    def _norms(self):
        if not self._grads_computed:
            self._grads()

        self.weight.norms = \
            self.weight.grads.pow(2).sum(dim=[1, 2, 3, 4]).sqrt_()
        if self.bias is not None:
            self.bias.norms = self.bias.grads.pow(2).sum(dim=1).sqrt_()

    def _weighted_grad(self):
        if not self._grads_computed:
            self._grads()

        self.weight.weighted_grad = \
            (self._weights_grads[(..., ) + (None, ) * 4] *
             self.weight.grads).sum(dim=0)
        if self.bias is not None:
            self.bias.weighted_grad = (self._weights_grads.unsqueeze(1) *
                                       self.bias.grads).sum(dim=0)

    def _clean(self):
        _Layer._clean(self)
        if self._grads_computed and not self.requires_grads:
            for p in self.parameters():
                del p.grads
        self._grads_computed = False
