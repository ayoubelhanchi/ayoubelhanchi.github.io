import torch
from .utils import (
    _grads_weight_conv2d,
    _grads_bias_conv2d,
    _norms_weight_linear,
    _norms_bias_linear,
    _weighted_grad_weight_linear,
    _weighted_grad_bias_linear
)


class _IsLayer:

    def __init__(self, layer, with_norms):
        self._layer = layer

        for p in self.parameters():
            p.requires_grad = False
        self._requires_is_grad = True
        self._with_norms = with_norms
        self._requires_norms = self._with_norms

        self._input = None
        self._output_grad = None
        self._weights_grads = None

    @property
    def requires_is_grad(self):
        return self._requires_is_grad

    @requires_is_grad.setter
    def requires_is_grad(self, requires_is_grad):
        if requires_is_grad:
            self._requires_is_grad = True
            self._requires_norms = self._with_norms
        else:
            self._requires_is_grad = False
            self._requires_norms = False

    @property
    def with_norms(self):
        return self._with_norms

    @with_norms.setter
    def with_norms(self, with_norms):
        self._with_norms = with_norms
        if self.requires_is_grad:
            self._requires_norms = self._with_norms

    def forward(self, input, weights_grads=None):
        if torch.is_grad_enabled() and self._requires_is_grad:
            self._check_requires_grad_conflict()
            self._check_weights_grads(input, weights_grads)
            self._weights_grads = weights_grads
            self._input = input.detach()  # detach from comp graph
        output = self._layer.forward(self, input)
        if torch.is_grad_enabled() and self._requires_is_grad:
            output.requires_grad_()
            output.register_hook(self._is_hook)
        return output

    def _check_requires_grad_conflict(self):
        for name, p in self.named_parameters():
            if p.requires_grad:
                raise ValueError("The attributes 'requires_grad' of " +
                                 "the parameters and the attribute " +
                                 "'requires_is_grad' of the layer " +
                                 "are mutually " +
                                 "exclusive. At most one of them can be " +
                                 "set to 'True' at the same time. " +
                                 "Parameter '{0}' ".format(name) +
                                 "has requires_grad=True, while " +
                                 "requires_is_grad=True.")

    @staticmethod
    def _check_weights_grads(input, weights_grads):
        if weights_grads is None:
            raise ValueError("argument 'weights_grads' is required" +
                             "when 'requires_is_grad=True'. " +
                             "argument 'weights_grad' is None" +
                             "while requires_is_grad=True")
        if type(weights_grads) != torch.Tensor:
            raise TypeError("argument 'weights_grads' must " +
                            "be a {0} not a {1}.".format(
                                torch.Tensor.__name__,
                                type(weights_grads).__name__
                            ))
        if weights_grads.shape != torch.Size([input.shape[0]]):
            raise ValueError("argument 'weights_grads' should be a " +
                             "one dimensional tensor of the same " +
                             "length as the first dimension " +
                             "of argument 'input'. " +
                             "Received a Tensor of shape {0}".format(
                                list(weights_grads.shape)
                             ))

    def _is_hook(self, grad):
        self._output_grad = grad  # grad is already detached
        self._is_grad()
        if self._requires_norms:
            self._norms()
        self._clean()

    def _is_grad(self):
        raise NotImplementedError

    def _norms(self):
        raise NotImplementedError

    def _clean(self):
        self._input = None
        self._output_grad = None
        self._weights_grads = None


class IsLinear(_IsLayer, torch.nn.Linear):

    def __init__(self, in_features, out_features, bias=True,
                 with_norms=True):
        torch.nn.Linear.__init__(self, in_features, out_features, bias)
        _IsLayer.__init__(self, torch.nn.Linear, with_norms)

    # the forward call is correctly made through the forward method
    # of _IsLayer since it is the first in python's MRO order.

    def _is_grad(self):
        self.weight.grad = _weighted_grad_weight_linear(self._input,
                                                        self._output_grad,
                                                        self._weights_grads)
        if self.bias is not None:
            self.bias.grad = _weighted_grad_bias_linear(self._output_grad,
                                                        self._weights_grads)

    def _norms(self):
        self.weight.norms = _norms_weight_linear(self._input,
                                                 self._output_grad)
        if self.bias is not None:
            self.bias.norms = _norms_bias_linear(self._output_grad)


class IsConv2d(_IsLayer, torch.nn.Conv2d):

    def __init__(self, in_channels, out_channels, kernel_size,
                 stride=1, padding=0, dilation=1, bias=True,
                 with_norms=True):
        torch.nn.Conv2d.__init__(self, in_channels, out_channels, kernel_size,
                                 stride, padding, dilation, bias=bias)
        _IsLayer.__init__(self, torch.nn.Conv2d, with_norms)

    # the forward call is correctly made through the forward method
    # of _IsLayer since it is the first in python's MRO order.

    def _is_grad(self):
        # computes the per_example gradients
        self.weight._grads = _grads_weight_conv2d(self._input,
                                                  self._output_grad,
                                                  self.kernel_size,
                                                  self.dilation,
                                                  self.padding,
                                                  self.stride)
        if self.bias is not None:
            self.bias._grads = _grads_bias_conv2d(self._output_grad)

        # computes the is_grad
        self.weight.grad = \
            (self._weights_grads[(..., ) + (None, ) * 4] *
             self.weight._grads).sum(dim=0)
        if self.bias is not None:
            self.bias.grad = (self._weights_grads.unsqueeze(1) *
                              self.bias._grads).sum(dim=0)

    def _norms(self):
        self.weight.norms = \
            self.weight._grads.pow(2).sum(dim=[1, 2, 3, 4]).sqrt_()
        if self.bias is not None:
            self.bias.norms = self.bias._grads.pow(2).sum(dim=1).sqrt_()

    def _clean(self):
        _IsLayer._clean(self)
        for p in self.parameters():
            del p._grads
