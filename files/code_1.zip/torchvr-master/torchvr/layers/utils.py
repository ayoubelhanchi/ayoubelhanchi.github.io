import torch


# Helpers for Linear layer.
def _grad_weight_linear(input, output_grad):
    return output_grad.T @ input


def _grad_bias_linear(output_grad):
    return output_grad.sum(dim=0)


def _weighted_grad_weight_linear(input, output_grad, weights):
    return (weights * output_grad.T) @ input


def _weighted_grad_bias_linear(output_grad, weights):
    return (weights.unsqueeze(1) * output_grad).sum(dim=0)


def _norms_weight_linear(input, output_grad):
    return (output_grad.pow(2).sum(dim=1) * input.pow(2).sum(dim=1)).sqrt_()


def _norms_bias_linear(output_grad):
    return output_grad.pow(2).sum(dim=1).sqrt_()


def _grads_weight_linear(input, output_grad):
    d_in = input.shape[1]
    d_out = output_grad.shape[1]
    return input.unsqueeze(1) * output_grad.unsqueeze(2).expand(-1, d_out, d_in)


def _grads_bias_linear(output_grad):
    return output_grad


# Helpers for Conv2d layer.
def _grads_weight_conv2d(input, output_grad, kernel_size,
                         dilation, padding, stride):
    c_in = input.shape[1]
    c_out = output_grad.shape[1]
    input_unf = torch.nn.functional.unfold(input, kernel_size,
                                           dilation, padding, stride)
    grads_weight = output_grad.flatten(2) @  input_unf.transpose(1, 2)
    return grads_weight.view(-1, c_out, c_in, kernel_size[0], kernel_size[1])


def _grads_bias_conv2d(output_grad):
    return output_grad.flatten(2).sum(dim=2)
