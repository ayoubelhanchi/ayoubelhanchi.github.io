# PyTorch Implementation of Variance-Reduced Gradient Estimation

This library provides PyTorch modules and samplers that produce efficient gradient estimators to accelerate training of large
scale models.