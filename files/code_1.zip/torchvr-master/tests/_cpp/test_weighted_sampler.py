import unittest
import torch

from _cpp import WeightedSampler
from utils import NaiveWeightedSampler, rel_error


class TestWeightedSampler(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.N = 100
        cls.S = 10
        init_weights = torch.rand(cls.N, dtype=torch.float64)

        cls.naive_sampler = NaiveWeightedSampler(init_weights)
        cls.naive_indices = torch.empty(cls.S, dtype=torch.int64)
        cls.naive_probs = torch.empty(cls.S, dtype=torch.float64)

        cls.sampler = WeightedSampler(init_weights)
        cls.indices = torch.empty(cls.S, dtype=torch.int64)
        cls.probs = torch.empty(cls.S, dtype=torch.float64)

        cls.uniforms = torch.empty(cls.S, dtype=torch.float64)

    def _test_sample(self, replace):
        self.uniforms.uniform_()
        self.naive_sampler.sample(self.uniforms, self.naive_indices,
                                  self.naive_probs, replace)
        self.sampler.sample(self.uniforms, self.indices, self.probs, replace)

        relative_error_probs = rel_error(self.probs, self.naive_probs)
        self.assertEqual(self.S,
                         (self.naive_indices == self.indices).sum().item())
        self.assertLess(relative_error_probs, 1e-12)

    def _test_update(self, mode):
        # tests before updating
        self._test_sample(True)
        self._test_sample(False)

        # updates
        indices = torch.randint(0, self.N, (self.S,), dtype=torch.int64)
        new_weights = torch.rand(self.S, dtype=torch.float64)
        self.naive_sampler.update(indices, new_weights, mode)
        self.sampler.update(indices, new_weights, mode)

        # tests after updating
        self._test_sample(True)
        self._test_sample(False)

    def test_real_use_case(self):
        num_iter = 10
        for _ in range(num_iter):
            for mode in range(4):
                self._test_update(mode)

    def test_get_probs(self):
        naive_probs = self.naive_sampler.get_probs()
        probs = torch.from_numpy(self.sampler.get_probs())
        relative_error_probs = rel_error(naive_probs, probs)
        self.assertLess(relative_error_probs, 1e-12)


if __name__ == "__main__":
    unittest.main()
