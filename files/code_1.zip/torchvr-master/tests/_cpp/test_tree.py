import unittest
import random

from _cpp import Tree
from utils import NaiveTree, rel_error


class TestTree(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.N = 100
        cls.S = 80
        keys = [random.random() for _ in range(cls.N)]

        cls.naive_tree = NaiveTree(cls.N)
        cls.tree = Tree(cls.N)
        for i, k in enumerate(keys):
            cls.naive_tree.set_key_at_index(i, k)
            cls.tree.set_key_at_index(i, k)
        cls.naive_tree.fix()

    def _test_get_sum_of_values(self):
        relative_error = rel_error(self.tree.get_sum_of_keys(),
                                   self.naive_tree.get_sum_of_keys())
        self.assertLess(relative_error, 1e-12)

    def _test_get_value_at_index(self):
        for i in range(self.N):
            if i not in self.naive_tree.hidden:
                relative_error = rel_error(self.tree.get_key_at_index(i),
                                           self.naive_tree.get_key_at_index(i))
                self.assertLess(relative_error, 1e-12)

    def _test_select_right(self):
        for r in range(1, self.N+1):
            if r <= self.N - self.naive_tree.n_hidden:
                naive_index = self.naive_tree.select_right(r)
                index = self.tree.select_right(r)
                self.assertEqual(index, naive_index)

    def _test_select_left(self):
        for r in range(1, self.N+1):
            if r <= self.N - self.naive_tree.n_hidden:
                naive_index = self.naive_tree.select_left(r)
                index = self.tree.select_left(r)
                self.assertEqual(index, naive_index)

    def _test_right_rank(self):
        for i in range(0, self.N):
            if i not in self.naive_tree.hidden:
                self.assertEqual(self.tree.right_rank(i),
                                 self.naive_tree.right_rank(i))

    def _test_left_rank(self):
        for i in range(0, self.N):
            if i not in self.naive_tree.hidden:
                self.assertEqual(self.tree.left_rank(i),
                                 self.naive_tree.left_rank(i))

    def _test_select_right_cumsum(self):
        for r in range(1, self.N+1):
            if r <= self.N - self.naive_tree.n_hidden:
                u = random.uniform(self.naive_tree.right_cumsums[r-1],
                                   self.naive_tree.right_cumsums[r])
                naive_index = self.naive_tree.select_right_cumsum(u)
                index = self.tree.select_right_cumsum(u)
                self.assertEqual(index, naive_index)

    def _test_select_left_cumsum(self):
        for r in range(1, self.N+1):
            if r <= self.N - self.naive_tree.n_hidden:
                r += self.naive_tree.n_hidden
                u = random.uniform(self.naive_tree.left_cumsums[r-1],
                                   self.naive_tree.left_cumsums[r])
                naive_index = self.naive_tree.select_left_cumsum(u)
                index = self.tree.select_left_cumsum(u)
                self.assertEqual(index, naive_index)

    def _test_right_cumsum(self):
        for i in range(0, self.N):
            if i not in self.naive_tree.hidden:
                relative_error = rel_error(self.tree.right_cumsum(i),
                                           self.naive_tree.right_cumsum(i))
                self.assertLess(relative_error, 1e-12)

    def _test_left_cumsum(self):
        for i in range(0, self.N):
            if i not in self.naive_tree.hidden:
                relative_error = rel_error(self.tree.left_cumsum(i),
                                           self.naive_tree.left_cumsum(i))
                self.assertLess(relative_error, 1e-12)

    def _test_order(self):
        self.assertEqual([x.key for x in self.tree.in_order_walk()],
                         self.naive_tree.in_order_walk())

    def _test_all(self):
        # self._test_order()

        self._test_select_right()
        self._test_select_left()
        self._test_right_rank()
        self._test_left_rank()

        self._test_select_right_cumsum()
        self._test_select_left_cumsum()
        self._test_right_cumsum()
        self._test_left_cumsum()

    def test_set_key_at_index(self):
        self._test_all()  # tests before setting

        new_keys = [random.random() for _ in range(self.S)]
        new_indices = \
            random.sample([i for i in range(self.N) if i not in self.naive_tree.hidden],
                          self.S)
        for i, k in zip(new_indices, new_keys):
            self.tree.set_key_at_index(i, k)
            self.naive_tree.set_key_at_index(i, k)
        self.naive_tree.fix()

        self._test_all()  # tests after setting

    def test_hide_unhide(self):
        self._test_all()  # test before hiding

        hidden_indices = [random.randint(0, self.N-1) for _ in range(self.S)]
        for i in hidden_indices:
            self.tree.hide(i)
            self.naive_tree.hide(i)
        self.naive_tree.fix()

        self._test_all()  # test after hiding

        for i in hidden_indices:
            self.tree.unhide(i)
            self.naive_tree.unhide(i)
        self.naive_tree.fix()

        self._test_all()  # test after unhiding


if __name__ == '__main__':
    unittest.main()
