import unittest
import torch

from _cpp import OptimalSampler
from utils import NaiveOptimalSampler, rel_error


class TestOptimalSampler(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.N = 100
        cls.S = 10
        init_weights = torch.rand(cls.N, dtype=torch.float64)

        cls.naive_sampler = NaiveOptimalSampler(init_weights)
        cls.naive_indices = torch.empty(cls.S, dtype=torch.int64)
        cls.naive_probs = torch.empty(cls.S, dtype=torch.float64)

        cls.sampler = OptimalSampler(init_weights)
        cls.indices = torch.empty(cls.S, dtype=torch.int64)
        cls.probs = torch.empty(cls.S, dtype=torch.float64)

        cls.uniforms = torch.empty(cls.S, dtype=torch.float64)

    def _test_sample(self, replace, delete=False):
        eps = torch.rand(1).item()/self.N
        self.uniforms.uniform_()

        self.naive_sampler.sample(self.uniforms,
                                  self.naive_indices, self.naive_probs,
                                  replace, eps)
        self.sampler.sample(self.uniforms,
                            self.indices, self.probs,
                            replace, eps, delete)

        relative_error_probs = rel_error(self.naive_probs, self.probs)
        self.assertEqual(self.S,
                         (self.naive_indices == self.indices).sum().item())
        self.assertLess(relative_error_probs, 1e-12)

    def _test_update(self, delete):
        # tests before updating
        self._test_sample(True)
        self._test_sample(False, delete)

        if not delete:
            indices = torch.randint(0, self.N, (self.S,), dtype=torch.int64)
        else:
            indices = self.indices
        new_weights = torch.rand(self.S, dtype=torch.float64)

        self.naive_sampler.update(indices, new_weights)
        self.sampler.update(indices, new_weights)

        # tests after updating
        self._test_sample(True)
        self._test_sample(False, False)

    def test_real_use_case(self):
        num_iter = 10
        for j in range(num_iter):
            self._test_update(False)
            self._test_update(True)

    def test_get_probs(self):
        eps = torch.rand(1).item()/self.N
        naive_probs = self.naive_sampler.get_probs(eps)
        probs = torch.from_numpy(self.sampler.get_probs(eps))
        relative_error_probs = rel_error(naive_probs, probs)
        self.assertLess(relative_error_probs, 1e-12)


if __name__ == '__main__':
    unittest.main()
