import unittest
import random

from _cpp import BIT
from utils import NaiveBIT, rel_error


class TestBIT(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.N = 100
        cls.S = 50
        values = [random.random() for _ in range(cls.N)]

        cls.bit = BIT(cls.N)
        cls.naive_bit = NaiveBIT(cls.N)
        for i, v in enumerate(values):
            cls.bit.set_value_at_index(i, v)
            cls.naive_bit.set_value_at_index(i, v)
        cls.naive_bit.fix()

    def _test_get_sum_of_values(self):
        relative_error = rel_error(self.bit.get_sum_of_values(),
                                   self.naive_bit.get_sum_of_values())
        self.assertLess(relative_error, 1e-12)

    def _test_get_value_at_index(self):
        for i in range(self.N):
            if i not in self.naive_bit.hidden:
                relative_error = rel_error(self.bit.get_value_at_index(i),
                                           self.naive_bit.get_value_at_index(i))
                self.assertLess(relative_error, 1e-12)

    def _test_cumsum(self):
        for i in range(self.N):
            if i not in self.naive_bit.hidden:
                relative_error = rel_error(self.bit.cumsum(i),
                                           self.naive_bit.cumsum(i))
                self.assertLess(relative_error, 1e-12)

    def _test_select_cumsum(self):
        for i in range(self.N):
            if i not in self.naive_bit.hidden:
                u = random.uniform(self.naive_bit.cumsum(i-1),
                                   self.naive_bit.cumsum(i))
                self.assertEqual(self.bit.select_cumsum(u),
                                 self.naive_bit.select_cumsum(u))

    def _test_all(self):
        self._test_get_sum_of_values()
        self._test_get_value_at_index()
        self._test_cumsum()
        self._test_select_cumsum()

    def test_set_value_at_index(self):
        self._test_all()  # tests before setting

        new_values = [random.random() for _ in range(self.S)]
        new_indices = \
            random.sample([i for i in range(self.N) if i not in self.naive_bit.hidden],
                          self.S)
        new_indices = [random.randint(0, self.N-1) for _ in range(self.S)]
        for i, v in zip(new_indices, new_values):
            self.bit.set_value_at_index(i, v)
            self.naive_bit.set_value_at_index(i, v)
        self.naive_bit.fix()

        self._test_all()  # test after setting

    def test_increment_value_at_index(self):
        self._test_all()  # tests before incrementing

        new_increments = [random.random() for _ in range(self.S)]
        new_indices = \
            random.sample([i for i in range(self.N) if i not in self.naive_bit.hidden],
                          self.S)
        for i, inc in zip(new_indices, new_increments):
            self.bit.increment_value_at_index(i, inc)
            self.naive_bit.increment_value_at_index(i, inc)
        self.naive_bit.fix()

        self._test_all()  # test after incrementing

    def test_multiply_value_at_index(self):
        self._test_all()  # tests before multiplying

        new_factors = [random.random() for _ in range(self.S)]
        new_indices = \
            random.sample([i for i in range(self.N) if i not in self.naive_bit.hidden],
                          self.S)
        for i, fac in zip(new_indices, new_factors):
            self.bit.multiply_value_at_index(i, fac)
            self.naive_bit.multiply_value_at_index(i, fac)
        self.naive_bit.fix()

        self._test_all()  # test after multiplying

    def test_increment_sqr_value_at_index(self):
        self._test_all()  # tests before multiplying

        new_inc_sqr = [random.random() for _ in range(self.S)]
        new_indices = \
            random.sample([i for i in range(self.N) if i not in self.naive_bit.hidden],
                          self.S)
        for i, inc_sqr in zip(new_indices, new_inc_sqr):
            self.bit.increment_sqr_value_at_index(i, inc_sqr)
            self.naive_bit.increment_sqr_value_at_index(i, inc_sqr)
        self.naive_bit.fix()

        self._test_all()  # test after multiplying

    def test_hide_unhide(self):
        self._test_all()  # test before hiding

        hidden_indices = [random.randint(0, self.N-1) for _ in range(self.S)]
        for i in hidden_indices:
            self.bit.hide(i)
            self.naive_bit.hide(i)
        self.naive_bit.fix()

        self._test_all()  # test after hiding

        for i in hidden_indices:
            self.bit.unhide(i)
            self.naive_bit.unhide(i)
        self.naive_bit.fix()

        self._test_all()  # test after unhiding


if __name__ == '__main__':
    unittest.main()
