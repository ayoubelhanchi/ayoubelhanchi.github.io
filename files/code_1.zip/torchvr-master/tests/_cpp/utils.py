from math import pow, sqrt
import torch


def rel_error(x_approx, x):
    if type(x) is torch.Tensor:
        x = x.flatten()
        x_approx = x_approx.flatten()
        errors = torch.abs(x - x_approx)
        max_error = torch.max(errors)
        argmax_error = torch.argmax(errors)
        return max_error/x[argmax_error]
    elif type(x) == list:
        return max([abs(y - y_approx)/y for y, y_approx in zip(x, x_approx)])
    else:
        return (x - x_approx)/x


class NaiveBIT:

    def __init__(self, N):
        self.N = N
        self.array = [0] * N
        self.cumsums = None
        self.hidden = dict()
        self.fix()

    def get_sum_of_values(self):
        return sum(self.array)

    def get_value_at_index(self, index):
        return self.array[index]

    def set_value_at_index(self, index, value):
        self.array[index] = value

    def increment_value_at_index(self, index, inc):
        self.array[index] += inc

    def multiply_value_at_index(self, index, fac):
        self.array[index] *= fac

    def increment_sqr_value_at_index(self, index, inc_sqr):
        self.array[index] = sqrt(pow(self.array[index], 2) + inc_sqr)

    def fix(self):
        self.cumsums = [sum(self.array[0:i]) for i in range(self.N+1)]

    def cumsum(self, i):
        return self.cumsums[i+1]

    def select_cumsum(self, u):
        return self.interval_search(u, self.cumsums)

    def hide(self, i):
        if i not in self.hidden:
            self.hidden[i] = self.array[i]
            self.array[i] = 0.0

    def unhide(self, i):
        if i in self.hidden:
            self.array[i] = self.hidden.pop(i)

    @staticmethod
    def interval_search(u, cumsums):
        "Returns the index whose interval contains u."
        left = 0
        right = len(cumsums) - 2
        while left <= right:
            middle = (int)((left + right)/2)
            left_end = cumsums[middle]
            right_end = cumsums[middle+1]
            if u < left_end:
                right = middle - 1
            elif u > right_end:
                left = middle + 1
            else:
                return middle
        raise ValueError("interval not found.")


class NaiveTree:

    # 'left_keys' are the 'keys' sorted increasingly.
    # 'left_perm' is the permutation that sorts
    # the keys increasingly. It can also be seen
    # as the map from indices in 'left_keys' to
    # indices in 'keys'.
    # 'left_inv_perm' is the permutation that
    # restores the original order of the keys
    # starting from their increasing order. It can
    # also be seen as the map from the indices of
    # 'keys' to 'left_keys'.
    # similarly for 'right_keys' and 'right_perm'.

    def __init__(self, N):
        self.N = N
        self.keys = [0] * N

        self.left_keys = None
        self.left_perm = None
        self.left_inv_perm = None
        self.left_cumsums = None

        self.right_keys = None
        self.right_perm = None
        self.right_inv_perm = None
        self.right_cumsums = None

        self.hidden = dict()
        self.n_hidden = len(self.hidden)

    def in_order_walk(self):
        return self.left_keys[self.n_hidden:]

    def get_sum_of_keys(self):
        return sum(self.keys)

    def get_key_at_index(self, index):
        return self.keys[index]

    def set_key_at_index(self, index, key):
        self.keys[index] = key

    def select_right(self, r):
        return self.right_perm[r - 1]

    def select_left(self, r):
        return self.left_perm[r + self.n_hidden - 1]

    def right_rank(self, i):
        return self.right_inv_perm[i] + 1

    def left_rank(self, i):
        return self.left_inv_perm[i] + 1 - self.n_hidden

    def select_right_cumsum(self, u):
        index = self.interval_search(u, self.right_cumsums)
        return self.right_perm[index]

    def select_left_cumsum(self, u):
        index = self.interval_search(u, self.left_cumsums)
        return self.left_perm[index]

    def right_cumsum(self, i):
        r = self.right_inv_perm[i]
        return self.right_cumsums[r+1]

    def left_cumsum(self, i):
        r = self.left_inv_perm[i]
        return self.left_cumsums[r+1]

    def fix(self):
        self.left_keys = sorted(self.keys)  # increasing order
        self.left_perm = sorted(range(len(self.keys)),
                                key=lambda k: self.keys[k], reverse=False)
        self.left_inv_perm = sorted(range(len(self.left_perm)),
                                    key=lambda k: self.left_perm[k], reverse=False)
        self.left_cumsums = [sum(self.left_keys[0:i]) for i in range(self.N+1)]

        self.right_keys = sorted(self.keys, reverse=True)  # decreasing order
        self.right_perm = sorted(range(len(self.keys)),
                                 key=lambda k: self.keys[k], reverse=True)
        self.right_inv_perm = sorted(range(len(self.right_perm)),
                                     key=lambda k: self.right_perm[k], reverse=False)
        self.right_cumsums = [sum(self.right_keys[0:i])
                              for i in range(self.N+1)]

    def hide(self, i):
        if i not in self.hidden:
            self.hidden[i] = self.keys[i]
            self.keys[i] = 0.0
            self.n_hidden += 1

    def unhide(self, i):
        if i in self.hidden:
            self.keys[i] = self.hidden.pop(i)
            self.n_hidden -= 1

    @staticmethod
    def interval_search(u, cumsums):
        "Returns the index whose interval contains u."
        left = 0
        right = len(cumsums) - 2
        while left <= right:
            middle = (int)((left + right)/2)
            left_end = cumsums[middle]
            right_end = cumsums[middle+1]
            if u < left_end:
                right = middle - 1
            elif u > right_end:
                left = middle + 1
            else:
                return middle
        raise ValueError("interval not found.")


class NaiveWeightedSampler:

    def __init__(self, init_weights):
        self.N = len(init_weights)
        self.weights = NaiveBIT(self.N)
        for i in range(self.N):
            self.weights.set_value_at_index(i, init_weights[i].item())
        self.weights.fix()

    def update(self, indices, new_weights, mode):
        for i, nw in zip(indices, new_weights):
            if mode == 0:
                self.weights.set_value_at_index(i.item(), nw.item())
            elif mode == 1:
                self.weights.increment_value_at_index(i.item(), nw.item())
            elif mode == 2:
                self.weights.multiply_value_at_index(i.item(), nw.item())
            elif mode == 3:
                self.weights.increment_sqr_value_at_index(i.item(), nw.item())
        self.weights.fix()

    def sample(self, uniforms, indices, probs, replace):
        # local variables for sampling
        s = self.weights.get_sum_of_values()
        nc = 1.0
        index = 0

        # samples from the optimal distribution without replacement
        for i in range(len(uniforms)):
            # get the [0,1) random variable
            u = uniforms[i].item()

            # finds index
            index = self.weights.select_cumsum(u * s * nc)
            indices[i] = index
            probs[i] = self.weights.get_value_at_index(index)/s

            # hides sampled index
            if not replace:
                self.weights.hide(index)
                self.weights.fix()
                nc -= probs[i].item()

        # unhides the sampled indices
        if not replace:
            for i in indices:
                # make sure its the integer not the tensor (i)
                self.weights.unhide(i.item())
            self.weights.fix()

    def get_probs(self):
        s = self.weights.get_sum_of_values()
        probs = list()
        for i in range(self.N):
            probs.append(self.weights.get_value_at_index(i) / s)
        return torch.as_tensor(probs, dtype=torch.float64)


class NaiveWeightedUniformSampler:

    def __init__(self, init_weights):
        self.N = len(init_weights)

        self.weights = NaiveBIT(self.N)
        self.elements = list(range(self.N))
        self.permutation = list(range(self.N))

        for i in range(self.N):
            self.weights.set_value_at_index(i, init_weights[i].item())
        self.weights.fix()

    def update(self, indices, new_weights, mode):
        for i, nw in zip(indices, new_weights):
            if mode == 0:
                self.weights.set_value_at_index(i.item(), nw.item())
            elif mode == 1:
                self.weights.increment_value_at_index(i.item(), nw.item())
            elif mode == 2:
                self.weights.multiply_value_at_index(i.item(), nw.item())
            elif mode == 3:
                self.weights.increment_sqr_value_at_index(i.item(), nw.item())
        self.weights.fix()

    def sample(self, bernoullis, uniforms, indices, probs, p_mix):
        # local variables for sampling
        s = self.weights.get_sum_of_values()
        nc = 1.0
        sampled_index = 0

        # samples from the mixture distribution
        for i in range(len(bernoullis)):
            # finds index
            if bernoullis[i]:
                sampled_index = self.weights.select_cumsum(
                    uniforms[i] * s * nc)
            else:
                sampled_index = (int)(uniforms[i] * self.N)

            # collects the index and prob
            indices[i] = sampled_index
            probs[i] = p_mix * (self.weights.get_value_at_index(sampled_index) / s) + \
                (1.0 - p_mix) / self.N

    def get_probs(self, p_mix):
        s = self.weights.get_sum_of_values()
        probs = list()
        for i in range(self.N):
            probs.append(p_mix * (self.weights.get_value_at_index(i) / s) +
                         (1.0 - p_mix) / self.N)
        return torch.as_tensor(probs, dtype=torch.float64)


class NaiveOptimalSampler:

    def __init__(self, init_weights):
        self.N = len(init_weights)
        self.weights = NaiveTree(self.N)
        for i in range(self.N):
            self.weights.set_key_at_index(i, init_weights[i].item())
        self.weights.fix()

        self.r_star = 0
        self.s_star = 0
        self.c_star = 0
        self.key_star = 0

    def update(self, indices, new_weights):
        for i, nw in zip(indices, new_weights):
            self.weights.set_key_at_index(i.item(), nw.item())
        self.weights.fix()

    def sample(self, uniforms, indices, probs,
               replace, eps):
        # solve the optimization problem
        self.solve(eps)

        # if keys are all 0, sample uniformly
        if self.r_star == 0:
            eps = 1/self.N

        # local variables for sampling
        nc = 1.0
        index = 0
        n_eps = self.N - self.r_star
        r_eps = 0
        s_gt_eps = self.s_star/self.c_star

        for i in range(len(uniforms)):
            u = uniforms[i].item()

            if u < 1 - (eps/nc) * n_eps:
                u *= s_gt_eps * nc
                index = self.weights.select_right_cumsum(u)
                indices[i] = index
                probs[i] = self.weights.get_key_at_index(index)/s_gt_eps

            else:
                u -= 1 - (eps/nc) * n_eps
                r_eps = (int)(u * nc / eps) + 1
                index = self.weights.select_left(r_eps)
                indices[i] = index
                probs[i] = eps

                if not replace:
                    n_eps -= 1

            # updates norm constant and hides weights whem sampling without
            # replacement
            if not replace:
                nc -= probs[i]
                self.weights.hide(index)
                self.weights.fix()

        # unhides the hidden nodes
        for index in indices:
            self.weights.unhide(index.item())
        self.weights.fix()

    def solve(self, eps):
        self.r_star = 1
        self.s_star = self.weights.right_keys[0]
        self.c_star = 1 - (self.N - self.r_star) * eps
        self.key_star = self.weights.right_keys[0]

        N = self.N
        for r, pair in enumerate(zip(self.weights.right_keys,
                                     self.weights.right_cumsums[1:])):
            k, s = pair
            r = r + 1
            c = 1 - (N - r) * eps
            if k >= eps * (s/c):
                self.r_star = r
                self.s_star = s
                self.c_star = 1 - (N - r) * eps
                self.key_star = k
            else:
                return

    def get_probs(self, eps, indices=None):
        self.solve(eps)
        probs = list()
        for i in range(self.N):
            k = self.weights.get_key_at_index(i)
            if k >= self.key_star:
                probs.append(k/(self.s_star/self.c_star))
            else:
                probs.append(eps)
        return torch.as_tensor(probs, dtype=torch.float64)
