import math
import torch
import torchvr


def CNN(layers='layers'):
    # generates the data
    # generates the images
    N = 100
    c_in = 3
    h_in = 16
    w_in = 16
    X = torch.randn(N, c_in, h_in, w_in)

    # generates the labels
    K = 10
    y = torch.multinomial(torch.ones(K), N, True)

    # defines and initializes the model
    c_out = 1
    kernel_size = (3, 3)
    stride = 1
    padding = 0
    dilation = 1
    bias_conv2d = True

    h_out = math.floor((h_in + 2 * padding - dilation *
                        (kernel_size[0] - 1) - 1)/stride + 1)
    w_out = math.floor((w_in + 2 * padding - dilation *
                        (kernel_size[1] - 1) - 1)/stride + 1)
    d_in = c_out * h_out * w_out
    d_out = K
    bias_lin = True

    class test_CNN(torchvr.Model):

        def __init__(self):
            super().__init__()
            if layers == 'layers':
                conv2d = torchvr.layers.Conv2d
                lin = torchvr.layers.Linear
            elif layers == 'is_layers':
                conv2d = torchvr.layers.IsConv2d
                lin = torchvr.layers.IsLinear
            else:  # layers == 'cv_layers'
                conv2d = torchvr.layers.CvConv2d
                lin = torchvr.layers.CvLinear
            self.conv2d = \
                conv2d(c_in, c_out, kernel_size,
                       stride, padding, dilation,
                       bias_conv2d)
            self.lin = lin(d_in, d_out, bias_lin)

        def forward(self, input, weights=None):
            output = self.conv2d(input, weights)
            output = torch.nn.functional.relu(output).flatten(1, -1)
            output = self.lin(output, weights)
            return output

    model = test_CNN()
    loss_func = torch.nn.CrossEntropyLoss(reduction='sum')
    weights = torch.randn(N)

    return (X, y, model, loss_func, weights)
