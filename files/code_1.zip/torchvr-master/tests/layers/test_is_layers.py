import unittest
import torch
from problems import CNN
import utils

torch.set_default_tensor_type(torch.DoubleTensor)


def rel_error(tensor, tensor_approx):
    tensor = tensor.flatten()
    tensor_approx = tensor_approx.flatten()
    errors = torch.abs(tensor - tensor_approx)
    max_error = torch.max(errors)
    argmax_error = torch.argmax(errors)
    return max_error/tensor[argmax_error]


class testLayers(unittest.TestCase):
    # to be continued

    @classmethod
    def setUpClass(cls):
        cls.X, cls.y, cls.model, cls.loss_func, cls.weights = CNN('is_layers')

    def test_is_grad(self):
        pass

    def test_norms(self):
        pass

    def test_requires_is_grad(self):
        pass

    def test_with_norms(self):
        pass


if __name__ == '__main__':
    unittest.main()
