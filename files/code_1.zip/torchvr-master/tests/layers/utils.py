import torch


# computes the maximum relative error between two tensors
def rel_error(tensor, tensor_approx):
    if type(tensor) is not torch.Tensor:
        tensor = torch.tensor(tensor)
    if type(tensor_approx) is not torch.Tensor:
        tensor_approx = torch.tensor(tensor_approx)
    tensor = tensor.flatten()
    tensor_approx = tensor_approx.flatten()
    errors = torch.abs(tensor - tensor_approx)
    max_error = torch.max(errors)
    argmax_error = torch.argmax(errors)
    return max_error/tensor[argmax_error]


# utils for test_layers
def naive_grads(X, y, model, loss_func,
                grads=False, norms=False, weights=None):
    N = X.shape[0]
    for p in model.parameters():
        if grads:
            p.naive_grads = torch.zeros([N] + list(p.shape))
        if norms:
            p.naive_norms = torch.zeros(N)
        if weights is not None:
            p.naive_weighted_grad = torch.zeros_like(p)

    for i in range(N):
        loss = loss_func(model(X[i:(i+1)]), y[i:(i+1)])
        loss.backward()
        for p in model.parameters():
            if grads:
                p.naive_grads[i] = p.grad.clone()
            if norms:
                p.naive_norms[i] = p.grad.pow(2).sum().sqrt()
            if weights is not None:
                p.naive_weighted_grad += weights[i] * p.grad
        model.zero_grad()


def efficient_grads(X, y, model, loss_func,
                    grads=False, norms=False, weights=None):
    if grads:
        model.requires_grads_()
    if norms:
        model.requires_norms_()
    if weights is not None:
        model.requires_weighted_grad_()
    loss = loss_func(model(X, weights), y)
    loss.backward()
    model.zero_grad()
    if grads:
        model.requires_grads_(False)
    if norms:
        model.requires_norms_(False)
    if weights is not None:
        model.requires_weighted_grad_(False)


# utils for test_is_layers
def is_fit(X, y, model, loss_func, num_iterations=100,
           batch_size=10, is_grad=False, norms=False):
    N = X.shape[0]
    if norms is False:
        for module in model.modules():
            if type(module) in ['IsLinear', 'IsConv2d']:
                module.with_norms = False

    for i in range(num_iterations):
        indices = torch.multinomial(torch.ones(N), batch_size, False)
        weights = torch.randn(batch_size)

        # computes the is_grad naively
        for module in model.modules():
            if type(module) in ['IsLinear', 'IsConv2d']:
                module.requires_is_grad = False
        for p in model.parameters():
            p.requires_grad = True

        naive_grads(X[indices], y[indices], model, loss_func, weights=weights)
        for p in model.parameters():
            p.naive_is_grad = p.naive_weighted_grad
            del p.naive_weighted_grad

        # computes the is_grad efficiently
        for p in model.parameters():
            p.requires_grad = False
        for module in model.modules():
            if type(module) in ['IsLinear', 'IsConv2d']:
                module.requires_is_grad = True

        output = model(X[indices], weights)
        loss = loss_func(output, y[indices])
        loss.backward()
    # to be continued
