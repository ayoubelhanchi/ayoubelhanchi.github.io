import unittest
import torch
import problems
import utils

torch.set_default_tensor_type(torch.DoubleTensor)


def rel_error(tensor, tensor_approx):
    tensor = tensor.flatten()
    tensor_approx = tensor_approx.flatten()
    errors = torch.abs(tensor - tensor_approx)
    max_error = torch.max(errors)
    argmax_error = torch.argmax(errors)
    return max_error/tensor[argmax_error]


class testLayers(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.X, cls.y, cls.model, cls.loss_func, cls.weights = problems.CNN()

    def test_grads(self):
        # computes the per-example gradients naively
        utils.naive_grads(self.X, self.y, self.model, self.loss_func,
                          grads=True)
        # computes the per-example gradients efficiently
        utils.efficient_grads(self.X, self.y, self.model, self.loss_func,
                              grads=True)
        # compares the results
        for p in self.model.parameters():
            relative_error = utils.rel_error(p.naive_grads, p.grads)
            self.assertLess(relative_error, 1e-10)

    def test_norms(self):
        # computes the norm of the per-example gradients naively
        utils.naive_grads(self.X, self.y, self.model, self.loss_func,
                          norms=True)
        # computes the norm of the per-example gradients naively
        utils.efficient_grads(self.X, self.y, self.model, self.loss_func,
                              norms=True)
        # compares the results
        for p in self.model.parameters():
            relative_error = utils.rel_error(p.naive_norms, p.norms)
            self.assertLess(relative_error, 1e-10)

    def test_weighted_grad(self):
        # computes the norm of the per-example gradients naively
        utils.naive_grads(self.X, self.y, self.model, self.loss_func,
                          weights=self.weights)
        # computes the norm of the per-example gradients naively
        utils.efficient_grads(self.X, self.y, self.model, self.loss_func,
                              weights=self.weights)
        # compares the results
        for p in self.model.parameters():
            relative_error = utils.rel_error(p.naive_weighted_grad,
                                             p.weighted_grad)
            self.assertLess(relative_error, 1e-10)


if __name__ == '__main__':
    unittest.main()
