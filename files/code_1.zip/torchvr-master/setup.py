from setuptools import setup, find_packages
from setup_helpers import Pybind11Extension, build_ext

__version__ = "0.0.1"
__sources__ = ["./torchvr/_cpp/bindings.cpp",
               "./torchvr/_cpp/data_structures/binary_indexed_tree/bit.cpp",
               "./torchvr/_cpp/data_structures/augmented_red_black_tree/node.cpp",
               "./torchvr/_cpp/data_structures/augmented_red_black_tree/tree.cpp",
               "./torchvr/_cpp/samplers/uniform/uniform_sampler.cpp",
               "./torchvr/_cpp/samplers/weighted/weighted_sampler.cpp",
               "./torchvr/_cpp/samplers/weighted/weighted_uniform_sampler.cpp",
               "./torchvr/_cpp/samplers/optimal/optimal_sampler.cpp",
               ]

__include_dirs__ = ["./torchvr/_cpp",
                    "./torchvr/_cpp/data_structures/binary_indexed_tree",
                    "./torchvr/_cpp/data_structures/augmented_red_black_tree",
                    "./torchvr/_cpp/samplers/uniform",
                    "./torchvr/_cpp/samplers/weighted",
                    "./torchvr/_cpp/samplers/optimal"]


ext_modules = [
    Pybind11Extension(
        "_cpp",
        sources=__sources__,
        include_dirs=__include_dirs__,
    ),
]

setup(
    name="torchvr",
    version=__version__,
    author="Ayoub El Hanchi",
    author_email="ayoub.elhanchi@mail.mcgill.ca",
    description="Variance-reduced gradient estimation in PyTorch.",
    url="",
    packages=find_packages(),
    cmdclass={"build_ext": build_ext},
    ext_modules=ext_modules,
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
