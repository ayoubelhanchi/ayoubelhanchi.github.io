import torch
from tqdm import tqdm
import matplotlib.pyplot as plt


class Problem:
    "Holds the elements of the optimization problem."

    def __init__(self, X, y, model, start, loss_func, reg):
        self.X = X
        self.y = y
        self.model = model
        self.start = start
        self.loss_func = loss_func
        self.reg = reg


class RunResult:
    """Expects a problem with a model with importance sampling layers,
    Keeps track of losses, variances, and optimal variances for a batch-size of 1.
    """

    def __init__(self, pb, sampler):
        self._pb = pb
        self._sampler = sampler

        self.losses = []
        self.opt_vars = []
        self.vars = []

    def step(self):
        # finds the loss
        loss = self._pb.loss_func(self._pb.model(
            self._pb.X, torch.ones(len(self._pb.X))), self._pb.y)
        loss.backward()
        with torch.no_grad():
            for p in self._pb.model.parameters():
                loss += self._pb.reg * p.pow(2).sum()/2
        self.losses.append(loss.item())

        # finds the optimal and current variances
        norms = torch.zeros(len(self._pb.X))
        for p in self._pb.model.parameters():
            norms += p.norms.pow(2)
        norms.sqrt_()
        self.opt_vars.append(norms.sum().pow(2).item())
        self.vars.append((norms.pow(2)/self._sampler.get_probs()).sum().item())

    def subopts(self, loss_star):
        losses = torch.as_tensor(self.losses)
        return (losses - loss_star).log10()

    def regrets(self):
        opt_vars = torch.as_tensor(self.opt_vars)
        vars = torch.as_tensor(self.vars)
        return (vars - opt_vars).cumsum(dim=0)

    def per_step_regrets(self):
        opt_vars = torch.as_tensor(self.opt_vars)
        vars = torch.as_tensor(self.vars)
        return (vars - opt_vars).log10()

    def per_step_relative_regrets(self):
        opt_vars = torch.as_tensor(self.opt_vars)
        vars = torch.as_tensor(self.vars)
        return ((vars-opt_vars)/opt_vars).log10()


class AveragedResult:

    def __init__(self, sampler_name):
        self.sampler_name = sampler_name
        self.runs = list()
        self.averages = None

    def step(self, run):
        self.runs.append(run)

    def all_results(self, loss_star):
        self.averages = dict()
        stats = ["subopts", "regrets",
                 "per_step_regrets", "per_step_relative_regrets"]
        for stat in stats:
            if stat == "subopts":
                tmp = [getattr(run, stat)(loss_star) for run in self.runs]
            else:
                tmp = [getattr(run, stat)() for run in self.runs]
            self.averages[stat] = torch.std_mean(
                torch.stack(tmp, dim=0), dim=0)

    def plt_results(self, stat):
        s, m = self.averages[stat]
        plt.plot(torch.arange(len(m)), m, label=self.sampler_name)
        plt.fill_between(torch.arange(len(m)), m-s, m+s, alpha=0.1)


def fit(pb, sampler, lr, schedule_lr=None,
        runs=10, epochs=10):
    """fits the model to the data using the given sampler
    to sample indices at each iteration.

    schedule_lr should be a function that takes an iteration number,
    and returns a learning rate.

    returns a Result object holding the results.
    """

    # initializes a result object that holds the results
    result = AveragedResult(type(sampler).__name__)

    # training loop
    for run in tqdm(range(runs)):
        pb.model.load_state_dict(pb.start)
        sampler.reset()
        if schedule_lr is not None:
            t = 1
        run_result = RunResult(pb, sampler)

        # get initial results
        run_result.step()

        for epoch in range(epochs):
            for indices in sampler:
                # computes the output of the model
                output = pb.model(pb.X[indices], sampler.weights)

                # computes the loss and run backward to obtain gradient
                loss = pb.loss_func(output, pb.y[indices])
                loss.backward()

                # decrease the step size if necessary
                if schedule_lr is not None:
                    lr = schedule_lr(t)

                # step of gradient descent
                with torch.no_grad():
                    for p in pb.model.parameters():
                        p -= lr * (p.grad + pb.reg * p)
                        p.grad.zero_()

                # updates the distribution of the sampler
                sampler.step()

                # update the iteration number
                if schedule_lr is not None:
                    t += 1

            # at the end of each epoch gather the results
            run_result.step()

        # adds the run to the overall results
        result.step(run_result)

    # return the result
    return result
